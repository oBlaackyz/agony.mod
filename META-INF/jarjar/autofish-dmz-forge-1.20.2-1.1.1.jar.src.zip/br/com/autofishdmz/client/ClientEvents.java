/*    */ package br.com.autofishdmz.client;
/*    */ 
/*    */ import net.minecraft.client.KeyMapping;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.client.ConfigScreenHandler;
/*    */ import net.minecraftforge.client.event.InputEvent;
/*    */ import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
/*    */ import net.minecraftforge.client.event.RenderGuiEvent;
/*    */ import net.minecraftforge.event.TickEvent;
/*    */ import net.minecraftforge.eventbus.api.EventPriority;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.ModLoadingContext;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
/*    */ 
/*    */ @EventBusSubscriber(modid = "autofishdmz", value = {Dist.CLIENT})
/*    */ public final class ClientEvents {
/* 21 */   private static final KeyMapping TOGGLE = new KeyMapping("key.autofishdmz.toggle", 295, "key.categories.autofishdmz");
/* 22 */   private static final KeyMapping SETTINGS = new KeyMapping("key.autofishdmz.settings", 296, "key.categories.autofishdmz");
/* 23 */   private static final KeyMapping DEBUG = new KeyMapping("key.autofishdmz.debug", 297, "key.categories.autofishdmz");
/* 24 */   private static final KeyMapping STOP = new KeyMapping("key.autofishdmz.stop", 299, "key.categories.autofishdmz");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void keys(InputEvent.Key paramKey) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*    */   public static void tick(TickEvent.ClientTickEvent event) {
/* 39 */     if (event.phase == TickEvent.Phase.END) ClientController.get().tick(); 
/*    */   }
/*    */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*    */   public static void frame(TickEvent.RenderTickEvent event) {
/* 43 */     if (event.phase == TickEvent.Phase.END) ClientController.get().frame(); 
/*    */   }
/*    */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*    */   public static void hud(RenderGuiEvent.Post event) {
/* 47 */     ClientController.get().hud(event.getGuiGraphics());
/*    */   }
/*    */   
/*    */   @EventBusSubscriber(modid = "autofishdmz", value = {Dist.CLIENT}, bus = Mod.EventBusSubscriber.Bus.MOD)
/*    */   public static final class Registration {
/*    */     public static void register(RegisterKeyMappingsEvent param1RegisterKeyMappingsEvent) {}
/*    */     
/*    */     @SubscribeEvent
/*    */     public static void setup(FMLClientSetupEvent event) {
/* 56 */       ModLoadingContext.get().registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class, () -> new ConfigScreenHandler.ConfigScreenFactory(()));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\ClientEvents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */