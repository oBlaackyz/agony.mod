/*    */ package br.com.autofishdmz.client;
/*    */ 
/*    */ 
/*    */ final class Field extends Record {
/*    */   private final String key;
/*    */   private final String label;
/*    */   private final EditBox input;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lbr/com/autofishdmz/client/AutoFishScreen$Field;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #21	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lbr/com/autofishdmz/client/AutoFishScreen$Field;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lbr/com/autofishdmz/client/AutoFishScreen$Field;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #21	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lbr/com/autofishdmz/client/AutoFishScreen$Field;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lbr/com/autofishdmz/client/AutoFishScreen$Field;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #21	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lbr/com/autofishdmz/client/AutoFishScreen$Field;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/* 21 */   private Field(String key, String label, EditBox input) { this.key = key; this.label = label; this.input = input; } public String key() { return this.key; } public String label() { return this.label; } public EditBox input() { return this.input; }
/*    */ 
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\AutoFishScreen$Field.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */