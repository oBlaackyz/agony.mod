/*    */ package br.com.autofishdmz.client;
/*    */ import br.com.autofishdmz.core.BotConfig;
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import java.io.Reader;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.nio.file.AtomicMoveNotSupportedException;
/*    */ import java.nio.file.CopyOption;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.StandardCopyOption;
/*    */ import java.nio.file.attribute.FileAttribute;
/*    */ import net.minecraftforge.fml.loading.FMLPaths;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ final class ConfigStore {
/* 17 */   private static final Logger LOG = LogUtils.getLogger();
/* 18 */   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
/* 19 */   static final Path PATH = FMLPaths.CONFIGDIR.get().resolve("autofish-dmz.json");
/*    */ 
/*    */   
/*    */   static BotConfig load() {
/* 23 */     if (Files.exists(PATH, new java.nio.file.LinkOption[0])) {
/* 24 */       try { Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8); 
/* 25 */         try { BotConfig botConfig1 = (BotConfig)GSON.fromJson(reader, BotConfig.class);
/* 26 */           if (botConfig1 == null) throw new IllegalArgumentException("JSON vazio"); 
/* 27 */           botConfig1.validate();
/* 28 */           BotConfig botConfig2 = botConfig1;
/* 29 */           if (reader != null) reader.close();  return botConfig2; } catch (Throwable throwable) { if (reader != null) try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception e)
/* 30 */       { LOG.error("AutoFish: configuracao invalida, usando padroes. Arquivo preservado: {}", PATH, e);
/* 31 */         return new BotConfig(); }
/*    */     
/*    */     }
/* 34 */     BotConfig config = new BotConfig(); 
/* 35 */     try { save(config); } catch (Exception e) { LOG.error("AutoFish: nao foi possivel salvar configuracao", e); }
/* 36 */      return config;
/*    */   }
/*    */   static BotConfig copy(BotConfig config) {
/* 39 */     return (BotConfig)GSON.fromJson(GSON.toJson(config), BotConfig.class);
/*    */   }
/*    */   static void save(BotConfig config) throws IOException {
/* 42 */     config.validate();
/* 43 */     Files.createDirectories(PATH.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
/* 44 */     if (Files.exists(PATH, new java.nio.file.LinkOption[0])) Files.copy(PATH, PATH.resolveSibling("autofish-dmz.json.bak"), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING }); 
/* 45 */     Path temporary = Files.createTempFile(PATH.getParent(), "autofish-dmz-", ".tmp", (FileAttribute<?>[])new FileAttribute[0]);
/*    */     
/* 47 */     try { Files.writeString(temporary, GSON.toJson(config) + GSON.toJson(config), StandardCharsets.UTF_8, new java.nio.file.OpenOption[0]); 
/* 48 */       try { Files.move(temporary, PATH, new CopyOption[] { StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING }); }
/* 49 */       catch (AtomicMoveNotSupportedException e) { Files.move(temporary, PATH, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING }); }  }
/* 50 */     finally { Files.deleteIfExists(temporary); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\ConfigStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */