/*     */ package br.com.autofishdmz.client;
/*     */ 
/*     */ import br.com.autofishdmz.core.BotConfig;
/*     */ import java.util.function.BooleanSupplier;
/*     */ import java.util.function.Consumer;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ public final class AutoFishScreen extends Screen {
/*     */   private final Screen parent;
/*     */   private final BotConfig draft;
/*     */   
/*     */   private static final class Field extends Record {
/*     */     private final String key;
/*     */     private final String label;
/*     */     private final EditBox input;
/*     */     
/*  21 */     private Field(String key, String label, EditBox input) { this.key = key; this.label = label; this.input = input; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lbr/com/autofishdmz/client/AutoFishScreen$Field;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #21	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*  21 */       //   0	7	0	this	Lbr/com/autofishdmz/client/AutoFishScreen$Field; } public String key() { return this.key; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lbr/com/autofishdmz/client/AutoFishScreen$Field;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #21	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lbr/com/autofishdmz/client/AutoFishScreen$Field; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lbr/com/autofishdmz/client/AutoFishScreen$Field;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #21	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lbr/com/autofishdmz/client/AutoFishScreen$Field;
/*  21 */       //   0	8	1	o	Ljava/lang/Object; } public String label() { return this.label; } public EditBox input() { return this.input; }
/*     */   
/*     */   }
/*     */   
/*  25 */   private final Map<String, String> values = new LinkedHashMap<>();
/*  26 */   private final List<Field> fields = new ArrayList<>();
/*  27 */   private String error = ""; private int left;
/*     */   private int contentWidth;
/*     */   
/*     */   public AutoFishScreen(Screen parent) {
/*  31 */     super((Component)Component.m_237113_("AutoFish DMZ • Configurações"));
/*  32 */     this.parent = parent;
/*  33 */     this.draft = ConfigStore.copy(ClientController.get().config());
/*  34 */     populateValues(this.draft);
/*     */   }
/*     */   
/*     */   private void populateValues(BotConfig config) {
/*  38 */     this.values.put("attract_interval", Double.toString(config.attract_interval));
/*  39 */     this.values.put("confirm_delay", Double.toString(config.confirm_delay));
/*  40 */     this.values.put("circle_trigger_radius", Double.toString(config.circle_trigger_radius));
/*  41 */     this.values.put("cast_retry_interval", Double.toString(config.cast_retry_interval));
/*  42 */     this.values.put("attract_timeout", Double.toString(config.attract_timeout));
/*  43 */     this.values.put("circle_latency", Double.toString(config.circle_latency));
/*  44 */     this.values.put("manual_scale", Double.toString(config.manual_scale));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void m_7856_() {
/*  49 */     this.fields.clear();
/*  50 */     this.contentWidth = Math.min(560, Math.max(200, this.f_96543_ - 32));
/*  51 */     this.left = (this.f_96543_ - this.contentWidth) / 2;
/*  52 */     int gap = 12;
/*  53 */     int columnWidth = (this.contentWidth - gap) / 2;
/*  54 */     boolean compact = (this.f_96544_ < 320);
/*  55 */     int bodyTop = compact ? 45 : 65;
/*  56 */     int rowHeight = compact ? 25 : 34;
/*  57 */     int fieldHeight = compact ? 16 : 20;
/*  58 */     addField("attract_interval", "Intervalo da atração (s)", "0,02 a 30 segundos entre cliques para atrair o peixe.", this.left, bodyTop, columnWidth, fieldHeight);
/*     */     
/*  60 */     addField("confirm_delay", "Espera para confirmar (s)", "0 a 60 segundos antes de confirmar o resgate.", this.left + columnWidth + gap, bodyTop, columnWidth, fieldHeight);
/*     */     
/*  62 */     addField("circle_trigger_radius", "Raio do círculo (px)", "60 a 310 pixels na escala original da macro.", this.left, bodyTop + rowHeight, columnWidth, fieldHeight);
/*     */     
/*  64 */     addField("cast_retry_interval", "Intervalo do arremesso (s)", "0,01 a 30 segundos entre tentativas de lançar a vara.", this.left + columnWidth + gap, bodyTop + rowHeight, columnWidth, fieldHeight);
/*     */     
/*  66 */     addField("attract_timeout", "Limite para atrair (s)", "1 a 3600 segundos sem peixe antes de reiniciar.", this.left, bodyTop + 2 * rowHeight, columnWidth, fieldHeight);
/*     */     
/*  68 */     addField("circle_latency", "Antecipação do círculo (s)", "0 a 0,5 segundo de previsão do movimento do anel.", this.left + columnWidth + gap, bodyTop + 2 * rowHeight, columnWidth, fieldHeight);
/*     */     
/*  70 */     addField("manual_scale", "Escala manual", "0,1 a 8. Usada somente quando a escala automática está desligada.", this.left, bodyTop + 3 * rowHeight, columnWidth, fieldHeight);
/*     */     
/*  72 */     addToggle(this.left + columnWidth + gap, bodyTop + 3 * rowHeight + 10, columnWidth, "Pescar minimizado", () -> this.draft.background_mode, value -> this.draft.background_mode = value.booleanValue(), "Continua com Esc, Alt+Tab ou jogo minimizado usando os dados da pesca Warriors. O jogo deve permanecer conectado.");
/*     */ 
/*     */ 
/*     */     
/*  76 */     int toggleY = bodyTop + 4 * rowHeight + 5;
/*  77 */     addToggle(this.left, toggleY, columnWidth, "Reset por Shift", () -> this.draft.allow_shift_reset, value -> this.draft.allow_shift_reset = value.booleanValue(), "Permite reiniciar com Shift após o tempo limite. Continua bloqueado durante e após minigames.");
/*     */ 
/*     */     
/*  80 */     addToggle(this.left + columnWidth + gap, toggleY, columnWidth, "Escala automática", () -> this.draft.auto_scale, value -> this.draft.auto_scale = value.booleanValue(), "Calcula a escala pela altura da imagem, como no aplicativo original.");
/*     */ 
/*     */     
/*  83 */     addToggle(this.left, toggleY + 24, columnWidth, "Gravar debug", () -> this.draft.debug_record, value -> this.draft.debug_record = value.booleanValue(), "Salva imagens e diagnóstico dos minigames.");
/*     */     
/*  85 */     addToggle(this.left + columnWidth + gap, toggleY + 24, columnWidth, "Mostrar painel", () -> this.draft.show_hud, value -> this.draft.show_hud = value.booleanValue(), "Exibe estado e contador de peixes dentro do jogo.");
/*     */ 
/*     */     
/*  88 */     int footerY = this.f_96544_ - 25;
/*  89 */     int buttonGap = 6;
/*  90 */     int buttonWidth = (this.contentWidth - 2 * buttonGap) / 3;
/*  91 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Salvar e voltar"), button -> save())
/*  92 */         .m_252987_(this.left, footerY, buttonWidth, 20).m_253136_());
/*  93 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Restaurar padrões"), button -> resetEditedFields())
/*  94 */         .m_252987_(this.left + buttonWidth + buttonGap, footerY, buttonWidth, 20).m_253136_());
/*  95 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Cancelar"), button -> m_7379_())
/*  96 */         .m_252987_(this.left + 2 * (buttonWidth + buttonGap), footerY, buttonWidth, 20).m_253136_());
/*  97 */     updateManualField();
/*     */   }
/*     */   
/*     */   private void addField(String key, String label, String help, int x, int labelY, int width, int height) {
/* 101 */     EditBox input = new EditBox(this.f_96547_, x, labelY + 10, width, height, (Component)Component.m_237113_(label));
/* 102 */     input.m_94199_(24);
/* 103 */     input.m_94144_(this.values.get(key));
/* 104 */     input.m_94151_(value -> this.values.put(key, value));
/* 105 */     input.m_257544_(Tooltip.m_257550_((Component)Component.m_237113_(help)));
/* 106 */     this.fields.add(new Field(key, label, input));
/* 107 */     m_142416_((GuiEventListener)input);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addToggle(int x, int y, int width, String label, BooleanSupplier getter, Consumer<Boolean> setter, String help) {
/* 116 */     Button toggle = Button.m_253074_(toggleLabel(label, getter.getAsBoolean()), button -> { setter.accept(Boolean.valueOf(!getter.getAsBoolean())); button.m_93666_(toggleLabel(label, getter.getAsBoolean())); updateManualField(); }).m_252987_(x, y, width, 20).m_257505_(Tooltip.m_257550_((Component)Component.m_237113_(help))).m_253136_();
/* 117 */     m_142416_((GuiEventListener)toggle);
/*     */   }
/*     */   
/*     */   private static Component toggleLabel(String label, boolean enabled) {
/* 121 */     return (Component)Component.m_237113_(label + ": " + label);
/*     */   }
/*     */   
/*     */   private void updateManualField() {
/* 125 */     for (Field field : this.fields) {
/* 126 */       if (field.key().equals("manual_scale")) field.input().m_94186_(!this.draft.auto_scale); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resetEditedFields() {
/* 131 */     BotConfig defaults = new BotConfig();
/* 132 */     populateValues(defaults);
/* 133 */     this.draft.allow_shift_reset = defaults.allow_shift_reset;
/* 134 */     this.draft.auto_scale = defaults.auto_scale;
/* 135 */     this.draft.debug_record = defaults.debug_record;
/* 136 */     this.draft.show_hud = defaults.show_hud;
/* 137 */     this.draft.background_mode = defaults.background_mode;
/* 138 */     this.error = "";
/* 139 */     m_169413_();
/* 140 */     m_7856_();
/*     */   }
/*     */   private double number(String key, double min, double max) {
/*     */     double value;
/* 144 */     String label = ((Field)this.fields.stream().filter(field -> field.key().equals(key)).findFirst().orElseThrow()).label();
/*     */     
/*     */     try {
/* 147 */       value = Double.parseDouble(((String)this.values.get(key)).trim().replace(',', '.'));
/* 148 */     } catch (NumberFormatException e) {
/* 149 */       throw new IllegalArgumentException(label + ": digite um número válido.");
/*     */     } 
/* 151 */     if (!Double.isFinite(value) || value < min || value > max) {
/* 152 */       throw new IllegalArgumentException(label + ": use um valor entre " + label + " e " + min + ".");
/*     */     }
/* 154 */     return value;
/*     */   }
/*     */   
/*     */   private void save() {
/*     */     try {
/* 159 */       BotConfig candidate = ConfigStore.copy(this.draft);
/* 160 */       candidate.attract_interval = number("attract_interval", 0.02D, 30.0D);
/* 161 */       candidate.confirm_delay = number("confirm_delay", 0.0D, 60.0D);
/* 162 */       candidate.circle_trigger_radius = number("circle_trigger_radius", 60.0D, 310.0D);
/* 163 */       candidate.cast_retry_interval = number("cast_retry_interval", 0.01D, 30.0D);
/* 164 */       candidate.attract_timeout = number("attract_timeout", 1.0D, 3600.0D);
/* 165 */       candidate.circle_latency = number("circle_latency", 0.0D, 0.5D);
/* 166 */       candidate.manual_scale = number("manual_scale", 0.1D, 8.0D);
/* 167 */       candidate.validate();
/* 168 */       ClientController.get().saveConfig(candidate);
/* 169 */       m_7379_();
/* 170 */     } catch (IllegalArgumentException e) {
/* 171 */       this.error = e.getMessage();
/* 172 */     } catch (IOException e) {
/* 173 */       this.error = "Não foi possível salvar a configuração. Verifique a pasta config e o log.";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_88315_(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
/* 179 */     graphics.m_280024_(0, 0, this.f_96543_, this.f_96544_, -266853320, -267907045);
/* 180 */     graphics.m_280653_(this.f_96547_, this.f_96539_, this.f_96543_ / 2, 10, 6609135);
/* 181 */     ClientController controller = ClientController.get();
/*     */     
/* 183 */     String status = (controller.running() ? "Ligado • Suspenso neste menu" : "Pausado") + "  |  Peixes: " + (controller.running() ? "Ligado • Suspenso neste menu" : "Pausado");
/* 184 */     graphics.m_280137_(this.f_96547_, status, this.f_96543_ / 2, 26, 12504029);
/* 185 */     for (Field field : this.fields) {
/* 186 */       String label = this.f_96547_.m_92834_(field.label(), field.input().m_5711_());
/* 187 */       graphics.m_280056_(this.f_96547_, label, field.input().m_252754_(), field.input().m_252907_() - 10, 14148592, false);
/*     */     } 
/* 189 */     if (!this.error.isEmpty()) {
/*     */       
/* 191 */       String visibleError = this.f_96547_.m_92834_(this.error, this.contentWidth);
/* 192 */       graphics.m_280056_(this.f_96547_, visibleError, this.left, this.f_96544_ - 38, 16751001, false);
/*     */     } 
/* 194 */     super.m_88315_(graphics, mouseX, mouseY, partialTick);
/*     */   }
/*     */ 
/*     */   
/*     */   public void m_7379_() {
/* 199 */     if (this.f_96541_ != null) this.f_96541_.m_91152_(this.parent);
/*     */   
/*     */   }
/*     */   
/*     */   public boolean m_7043_() {
/* 204 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\AutoFishScreen.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */