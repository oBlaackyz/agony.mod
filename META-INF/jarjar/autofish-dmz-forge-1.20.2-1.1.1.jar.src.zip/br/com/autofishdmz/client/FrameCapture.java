/*    */ package br.com.autofishdmz.client;
/*    */ 
/*    */ import br.com.autofishdmz.core.PixelSource;
/*    */ import com.mojang.blaze3d.pipeline.RenderTarget;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL15;
/*    */ import org.lwjgl.opengl.GL30;
/*    */ import org.lwjgl.system.MemoryUtil;
/*    */ 
/*    */ final class FrameCapture
/*    */   implements PixelSource
/*    */ {
/*    */   private ByteBuffer pixels;
/*    */   private int x0;
/*    */   
/*    */   void read(RenderTarget target, double scale) {
/* 19 */     int fullWidth = target.f_83917_, fullHeight = target.f_83918_;
/* 20 */     this.x0 = Math.max(0, (int)(fullWidth / 2.0D - 330.0D * scale));
/* 21 */     this.y0 = Math.max(0, (int)(fullHeight / 2.0D - 330.0D * scale));
/* 22 */     this.width = Math.min(fullWidth, (int)(fullWidth / 2.0D + 330.0D * scale)) - this.x0;
/* 23 */     this.height = Math.min(fullHeight, (int)(fullHeight / 2.0D + 460.0D * scale)) - this.y0;
/* 24 */     int size = Math.multiplyExact(Math.multiplyExact(this.width, this.height), 4);
/* 25 */     if (this.pixels == null || this.pixels.capacity() != size) {
/* 26 */       close();
/* 27 */       this.pixels = MemoryUtil.memAlloc(size);
/*    */     } 
/* 29 */     int previousFbo = GL11.glGetInteger(36010);
/* 30 */     int packBuffer = GL11.glGetInteger(35053);
/* 31 */     int alignment = GL11.glGetInteger(3333);
/* 32 */     int rowLength = GL11.glGetInteger(3330);
/* 33 */     int skipRows = GL11.glGetInteger(3331);
/* 34 */     int skipPixels = GL11.glGetInteger(3332);
/* 35 */     GL30.glBindFramebuffer(36008, target.f_83920_);
/* 36 */     int readBuffer = GL11.glGetInteger(3074);
/*    */     try {
/* 38 */       GL15.glBindBuffer(35051, 0);
/* 39 */       GL11.glPixelStorei(3333, 1);
/* 40 */       GL11.glPixelStorei(3330, 0);
/* 41 */       GL11.glPixelStorei(3331, 0);
/* 42 */       GL11.glPixelStorei(3332, 0);
/* 43 */       GL11.glReadBuffer(36064);
/* 44 */       this.pixels.clear();
/* 45 */       GL11.glReadPixels(this.x0, fullHeight - this.y0 - this.height, this.width, this.height, 6408, 5121, this.pixels);
/*    */     } finally {
/* 47 */       GL11.glReadBuffer(readBuffer);
/* 48 */       GL30.glBindFramebuffer(36008, previousFbo);
/* 49 */       GL15.glBindBuffer(35051, packBuffer);
/* 50 */       GL11.glPixelStorei(3333, alignment);
/* 51 */       GL11.glPixelStorei(3330, rowLength);
/* 52 */       GL11.glPixelStorei(3331, skipRows);
/* 53 */       GL11.glPixelStorei(3332, skipPixels);
/*    */     } 
/*    */   }
/*    */   private int y0; private int width; private int height;
/*    */   public int rgb(int x, int y) {
/* 58 */     int localX = Math.max(0, Math.min(this.width - 1, x - this.x0));
/* 59 */     int localY = Math.max(0, Math.min(this.height - 1, y - this.y0));
/* 60 */     int offset = ((this.height - 1 - localY) * this.width + localX) * 4;
/* 61 */     return (this.pixels.get(offset) & 0xFF) << 16 | (this.pixels.get(offset + 1) & 0xFF) << 8 | this.pixels.get(offset + 2) & 0xFF;
/*    */   }
/*    */   
/*    */   BufferedImage snapshot() {
/* 65 */     BufferedImage image = new BufferedImage(this.width, this.height, 1);
/* 66 */     int[] row = new int[this.width];
/* 67 */     for (int y = 0; y < this.height; y++) {
/* 68 */       for (int x = 0; x < this.width; ) { row[x] = rgb(x + this.x0, y + this.y0); x++; }
/* 69 */        image.setRGB(0, y, this.width, 1, row, 0, this.width);
/*    */     } 
/* 71 */     return image;
/*    */   }
/*    */   void close() {
/* 74 */     if (this.pixels != null) { MemoryUtil.memFree(this.pixels); this.pixels = null; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\FrameCapture.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */