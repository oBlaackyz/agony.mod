/*     */ package br.com.autofishdmz.client;
/*     */ 
/*     */ import br.com.autofishdmz.core.NativeFishingSnapshot;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WarriorsFishingBridge
/*     */ {
/*     */   private static final String BASE = "com.nonopichy.yggdrasilremake.";
/*     */   private final Access access;
/*     */   private final String unavailableReason;
/*     */   
/*     */   private WarriorsFishingBridge(Access access, String unavailableReason) {
/*  32 */     this.access = access;
/*  33 */     this.unavailableReason = unavailableReason;
/*     */   }
/*     */   
/*     */   public static WarriorsFishingBridge create() {
/*     */     try {
/*  38 */       return new WarriorsFishingBridge(new Access(), "");
/*  39 */     } catch (ClassNotFoundException e) {
/*  40 */       return new WarriorsFishingBridge(null, "WarriorsExtra compativel nao encontrado");
/*  41 */     } catch (ReflectiveOperationException|RuntimeException|LinkageError e) {
/*  42 */       return new WarriorsFishingBridge(null, "Versao de pesca incompativel: " + e.getClass().getSimpleName());
/*     */     } 
/*     */   }
/*     */   
/*  46 */   public boolean available() { return (this.access != null); } public String unavailableReason() {
/*  47 */     return this.unavailableReason;
/*     */   }
/*     */   public NativeFishingSnapshot sample() {
/*  50 */     requireClientThread();
/*     */     try {
/*  52 */       Object session = this.access.session.get((Object)null);
/*  53 */       if (session == null) return NativeFishingSnapshot.idle(); 
/*  54 */       Object playerState = this.access.playerState.get(session);
/*  55 */       Object rules = this.access.rules.get(session);
/*  56 */       int rawPhase = this.access.phase.getByte(playerState);
/*  57 */       NativeFishingSnapshot.Phase phase = phase(rawPhase);
/*  58 */       int hits = this.access.hits.getInt(session);
/*  59 */       boolean arcReady = (phase == NativeFishingSnapshot.Phase.ARC && arcReady(session, rules));
/*  60 */       boolean circleReady = (phase == NativeFishingSnapshot.Phase.CIRCLE && circleReady(session));
/*  61 */       boolean canConfirm = (phase == NativeFishingSnapshot.Phase.RESULT && ((Double)invoke(this.access.phaseTime, playerState, new Object[0])).doubleValue() > 1.6D);
/*  62 */       return new NativeFishingSnapshot(((Integer)invoke(this.access.sessionId, rules, new Object[0])).intValue(), phase, this.access.sequence
/*  63 */           .getInt(session), hits, arcReady, circleReady, this.access.won
/*  64 */           .getBoolean(session), canConfirm, (this.access.biteAt.getLong(session) > 0L));
/*  65 */     } catch (ReflectiveOperationException e) {
/*  66 */       throw failure("ler a sessao de pesca", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean click() {
/*  72 */     requireClientThread();
/*     */     try {
/*  74 */       Object session = this.access.session.get((Object)null);
/*  75 */       if (session == null) return false; 
/*  76 */       ClickStamp before = stamp(session);
/*  77 */       int phase = this.access.phase.getByte(this.access.playerState.get(session));
/*     */ 
/*     */       
/*  80 */       if (phase >= 6 && phase <= 8) {
/*  81 */         if (!arcReady(session, this.access.rules.get(session))) return false; 
/*  82 */       } else if (phase == 10) {
/*  83 */         if (!circleReady(session)) return false; 
/*  84 */       } else if (phase == 13 || phase == 14) {
/*  85 */         if (((Double)invoke(this.access.phaseTime, this.access.playerState.get(session), new Object[0])).doubleValue() <= 1.6D) return false; 
/*  86 */       } else if (phase == 3) {
/*     */ 
/*     */         
/*  89 */         if (this.access.biteAt.getLong(session) > 0L) return false; 
/*  90 */       } else if (phase != 3) {
/*  91 */         return false;
/*     */       } 
/*  93 */       invoke(this.access.click, null, new Object[0]);
/*  94 */       Object after = this.access.session.get((Object)null);
/*  95 */       return (after != session || !before.equals(stamp(session)));
/*  96 */     } catch (ReflectiveOperationException e) {
/*  97 */       throw failure("clicar na pesca", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean start() {
/* 106 */     requireClientThread();
/* 107 */     Minecraft minecraft = Minecraft.m_91087_();
/* 108 */     if (minecraft.f_91074_ == null || minecraft.f_91073_ == null || !minecraft.f_91074_.m_6084_()) return false; 
/*     */     try {
/* 110 */       if (this.access.session.get((Object)null) != null) return false;
/*     */       
/* 112 */       invoke(this.access.findPoint, null, new Object[] { minecraft });
/* 113 */       Object point = this.access.nearbyPoint.get((Object)null);
/* 114 */       if (point == null || !((Boolean)invoke(this.access.pointUnlocked, point, new Object[0])).booleanValue() || (
/* 115 */         (Boolean)invoke(this.access.pointOccupied, null, new Object[] { point })).booleanValue()) return false; 
/* 116 */       long time = System.currentTimeMillis();
/* 117 */       if (time - this.access.lastStart.getLong((Object)null) < 1000L) return false; 
/* 118 */       String id = (String)invoke(this.access.pointId, point, new Object[0]);
/* 119 */       Object packet = this.access.startPacket.newInstance(new Object[] { Byte.valueOf((byte)0), Integer.valueOf(0), id, Byte.valueOf((byte)0), Byte.valueOf((byte)0), Integer.valueOf(2) });
/*     */       
/* 121 */       this.access.lastStart.setLong((Object)null, time);
/* 122 */       invoke(this.access.sendToServer, null, new Object[] { packet });
/* 123 */       return true;
/* 124 */     } catch (ReflectiveOperationException e) {
/* 125 */       throw failure("iniciar a pesca", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean cancel() {
/* 131 */     requireClientThread();
/*     */     try {
/* 133 */       Object session = this.access.session.get((Object)null);
/* 134 */       if (session == null) return false; 
/* 135 */       int phase = this.access.phase.getByte(this.access.playerState.get(session));
/* 136 */       if (phase < 1 || phase > 4) return false; 
/* 137 */       invoke(this.access.changePhase, null, new Object[] { Byte.valueOf((byte)16) });
/* 138 */       return true;
/* 139 */     } catch (ReflectiveOperationException e) {
/* 140 */       throw failure("cancelar a pesca", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ClickStamp stamp(Object session) throws IllegalAccessException {
/* 145 */     return new ClickStamp(this.access.sequence.getInt(session), this.access.attracted.getInt(session), this.access.hits
/* 146 */         .getInt(session), this.access.errors.getInt(session), this.access.grade.getByte(session), this.access.lastClick
/* 147 */         .getLong(session), this.access.finishAt.getLong(session));
/*     */   }
/*     */   
/*     */   private boolean arcReady(Object session, Object rules) throws ReflectiveOperationException {
/* 151 */     return (!this.access.escaped.getBoolean(session) && this.access.hits
/* 152 */       .getInt(session) < ((Byte)invoke(this.access.requiredHits, rules, new Object[0])).byteValue() && this.access.errors
/* 153 */       .getInt(session) <= ((Byte)invoke(this.access.allowedErrors, rules, new Object[0])).byteValue() && (
/* 154 */       (Long)invoke(this.access.clock, null, new Object[0])).longValue() - this.access.lastClick.getLong(session) >= 220L && (
/* 155 */       (Boolean)invoke(this.access.inZone, null, new Object[] { Float.valueOf(((Float)invoke(this.access.marker, null, new Object[0])).floatValue()) })).booleanValue());
/*     */   }
/*     */   
/*     */   private boolean circleReady(Object session) throws ReflectiveOperationException {
/* 159 */     if (this.access.escaped.getBoolean(session) || this.access.grade.getByte(session) >= 0) return false; 
/* 160 */     double progress = ((Double)invoke(this.access.circleProgress, null, new Object[0])).doubleValue();
/*     */     
/* 162 */     return (Double.isFinite(progress) && Math.abs(1.0D - progress) <= 0.2D);
/*     */   }
/*     */   private static final class ClickStamp extends Record { private final int sequence; private final int attracted; private final int hits; private final int errors; private final byte grade; private final long lastClick; private final long finishAt;
/* 165 */     private ClickStamp(int sequence, int attracted, int hits, int errors, byte grade, long lastClick, long finishAt) { this.sequence = sequence; this.attracted = attracted; this.hits = hits; this.errors = errors; this.grade = grade; this.lastClick = lastClick; this.finishAt = finishAt; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lbr/com/autofishdmz/client/WarriorsFishingBridge$ClickStamp;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #165	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lbr/com/autofishdmz/client/WarriorsFishingBridge$ClickStamp; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lbr/com/autofishdmz/client/WarriorsFishingBridge$ClickStamp;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #165	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lbr/com/autofishdmz/client/WarriorsFishingBridge$ClickStamp; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lbr/com/autofishdmz/client/WarriorsFishingBridge$ClickStamp;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #165	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lbr/com/autofishdmz/client/WarriorsFishingBridge$ClickStamp;
/* 165 */       //   0	8	1	o	Ljava/lang/Object; } public int sequence() { return this.sequence; } public int attracted() { return this.attracted; } public int hits() { return this.hits; } public int errors() { return this.errors; } public byte grade() { return this.grade; } public long lastClick() { return this.lastClick; } public long finishAt() { return this.finishAt; }
/*     */      }
/*     */   
/*     */   private static NativeFishingSnapshot.Phase phase(int phase) {
/* 169 */     switch (phase) { case 1: case 2: 
/*     */       case 3: 
/*     */       case 6: case 7: case 8: 
/*     */       case 10: 
/*     */       case 13: case 14: 
/*     */       case 4: case 5: case 9: case 11: case 12: case 15:
/*     */       case 16:
/* 176 */        }  throw new IllegalStateException("Fase de pesca desconhecida: " + phase);
/*     */   }
/*     */ 
/*     */   
/*     */   private void requireClientThread() {
/* 181 */     if (!available()) throw new IllegalStateException(this.unavailableReason); 
/* 182 */     if (!Minecraft.m_91087_().m_18695_()) throw new IllegalStateException("Pesca fora da thread do cliente"); 
/*     */   }
/*     */   
/*     */   private static Object invoke(Method method, Object target, Object... args) throws ReflectiveOperationException {
/* 186 */     return method.invoke(target, args);
/*     */   }
/*     */   
/*     */   private static IllegalStateException failure(String action, ReflectiveOperationException exception) {
/* 190 */     if (exception instanceof InvocationTargetException) { InvocationTargetException invocation = (InvocationTargetException)exception; if (invocation.getCause() != null); }
/* 191 */      Throwable cause = exception;
/* 192 */     return new IllegalStateException("Falha ao " + action + " no WarriorsExtra", cause);
/*     */   }
/*     */   private static final class Access { final Field session; final Field nearbyPoint; final Field lastStart; final Field playerState; final Field rules; final Field phase; final Field sequence; final Field hits; final Field errors;
/*     */     final Field attracted;
/*     */     final Field grade;
/*     */     final Field escaped;
/*     */     final Field won;
/*     */     final Field lastClick;
/*     */     final Field finishAt;
/*     */     final Field biteAt;
/*     */     
/*     */     Access() throws ReflectiveOperationException {
/* 204 */       ClassLoader loader = WarriorsFishingBridge.class.getClassLoader();
/* 205 */       Class<?> client = Class.forName("com.nonopichy.yggdrasilremake.client.warriors.pesca.PescaClient", false, loader);
/* 206 */       Class<?> sessionType = Class.forName("com.nonopichy.yggdrasilremake.client.warriors.pesca.PescaClient$Sessao", false, loader);
/* 207 */       Class<?> playerType = Class.forName("com.nonopichy.yggdrasilremake.client.warriors.pesca.Pescador", false, loader);
/* 208 */       Class<?> rulesType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaPacotes$SessaoS2C", false, loader);
/* 209 */       Class<?> pointType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaPacotes$Ponto", false, loader);
/* 210 */       Class<?> packetType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaPacotes$AcaoC2S", false, loader);
/* 211 */       Class<?> networkType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.WarriorsNet", false, loader);
/* 212 */       Class<?> gameRulesType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaRegras", false, loader);
/* 213 */       Field protocol = field(gameRulesType, "VERSAO", int.class, true);
/* 214 */       if (!Modifier.isFinal(protocol.getModifiers()) || protocol.getInt((Object)null) != 2)
/* 215 */         throw new IllegalStateException("Protocolo de pesca diferente de 2"); 
/* 216 */       this.session = field(client, "sessao", sessionType, true);
/* 217 */       this.nearbyPoint = field(client, "pontoPerto", pointType, true);
/* 218 */       this.lastStart = field(client, "ultimoIniciar", long.class, true);
/* 219 */       this.playerState = field(sessionType, "ps", playerType, false);
/* 220 */       this.rules = field(sessionType, "regras", rulesType, false);
/* 221 */       this.phase = field(playerType, "fase", byte.class, false);
/* 222 */       this.sequence = field(sessionType, "seq", int.class, false);
/* 223 */       this.hits = field(sessionType, "acertos", int.class, false);
/* 224 */       this.errors = field(sessionType, "erros", int.class, false);
/* 225 */       this.attracted = field(sessionType, "atraidos", int.class, false);
/* 226 */       this.grade = field(sessionType, "nota", byte.class, false);
/* 227 */       this.escaped = field(sessionType, "escapou", boolean.class, false);
/* 228 */       this.won = field(sessionType, "ganhou", boolean.class, false);
/* 229 */       this.lastClick = field(sessionType, "ultimoClique", long.class, false);
/* 230 */       this.finishAt = field(sessionType, "fimEm", long.class, false);
/* 231 */       this.biteAt = field(sessionType, "mordidaEm", long.class, false);
/* 232 */       this.click = method(client, "clicar", boolean.class, true, new Class[0]);
/* 233 */       this.marker = method(client, "marcador", float.class, true, new Class[0]);
/* 234 */       this.inZone = method(client, "naZona", boolean.class, true, new Class[] { float.class });
/* 235 */       this.circleProgress = method(client, "progressoDaMira", double.class, true, new Class[0]);
/* 236 */       this.clock = method(client, "relogio", long.class, true, new Class[0]);
/* 237 */       this.phaseTime = method(playerType, "t", double.class, false, new Class[0]);
/* 238 */       this.sessionId = method(rulesType, "sessao", int.class, false, new Class[0]);
/* 239 */       this.requiredHits = method(rulesType, "acertos", byte.class, false, new Class[0]);
/* 240 */       this.allowedErrors = method(rulesType, "erros", byte.class, false, new Class[0]);
/* 241 */       this.findPoint = method(client, "procurarPonto", void.class, true, new Class[] { Minecraft.class });
/* 242 */       this.pointId = method(pointType, "id", String.class, false, new Class[0]);
/* 243 */       this.pointUnlocked = method(pointType, "liberado", boolean.class, false, new Class[0]);
/* 244 */       this.pointOccupied = method(client, "ocupado", boolean.class, true, new Class[] { pointType });
/* 245 */       this.sendToServer = method(networkType, "sendToServer", void.class, true, new Class[] { Object.class });
/* 246 */       this.changePhase = method(client, "mudar", void.class, true, new Class[] { byte.class });
/* 247 */       this.startPacket = packetType.getDeclaredConstructor(new Class[] { byte.class, int.class, String.class, byte.class, byte.class, int.class });
/* 248 */       if (!this.startPacket.trySetAccessible()) throw new IllegalAccessException("Construtor do pedido de pesca inacessivel"); 
/*     */     }
/*     */     final Method click; final Method marker; final Method inZone; final Method circleProgress; final Method clock; final Method phaseTime; final Method sessionId; final Method requiredHits; final Method allowedErrors; final Method findPoint; final Method pointId; final Method pointUnlocked; final Method pointOccupied; final Method sendToServer; final Method changePhase; final Constructor<?> startPacket;
/*     */     private static Field field(Class<?> owner, String name, Class<?> type, boolean isStatic) throws ReflectiveOperationException {
/* 252 */       Field field = owner.getDeclaredField(name);
/* 253 */       if (field.getType() != type || Modifier.isStatic(field.getModifiers()) != isStatic || !field.trySetAccessible())
/* 254 */         throw new NoSuchFieldException(owner.getSimpleName() + "." + owner.getSimpleName() + " incompativel"); 
/* 255 */       return field;
/*     */     }
/*     */ 
/*     */     
/*     */     private static Method method(Class<?> owner, String name, Class<?> result, boolean isStatic, Class<?>... params) throws ReflectiveOperationException {
/* 260 */       Method method = owner.getDeclaredMethod(name, params);
/* 261 */       if (method.getReturnType() != result || Modifier.isStatic(method.getModifiers()) != isStatic || !method.trySetAccessible())
/* 262 */         throw new NoSuchMethodException(owner.getSimpleName() + "." + owner.getSimpleName() + " incompativel"); 
/* 263 */       return method;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\WarriorsFishingBridge.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */