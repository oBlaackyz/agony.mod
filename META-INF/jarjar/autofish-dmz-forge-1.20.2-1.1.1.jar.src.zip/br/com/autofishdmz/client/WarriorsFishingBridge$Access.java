/*     */ package br.com.autofishdmz.client;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Access
/*     */ {
/*     */   final Field session;
/*     */   final Field nearbyPoint;
/*     */   final Field lastStart;
/*     */   final Field playerState;
/*     */   final Field rules;
/*     */   final Field phase;
/*     */   final Field sequence;
/*     */   final Field hits;
/*     */   final Field errors;
/*     */   final Field attracted;
/*     */   final Field grade;
/*     */   final Field escaped;
/*     */   final Field won;
/*     */   final Field lastClick;
/*     */   final Field finishAt;
/*     */   final Field biteAt;
/*     */   final Method click;
/*     */   final Method marker;
/*     */   final Method inZone;
/*     */   final Method circleProgress;
/*     */   final Method clock;
/*     */   final Method phaseTime;
/*     */   final Method sessionId;
/*     */   final Method requiredHits;
/*     */   final Method allowedErrors;
/*     */   final Method findPoint;
/*     */   final Method pointId;
/*     */   final Method pointUnlocked;
/*     */   final Method pointOccupied;
/*     */   final Method sendToServer;
/*     */   final Method changePhase;
/*     */   final Constructor<?> startPacket;
/*     */   
/*     */   Access() throws ReflectiveOperationException {
/* 204 */     ClassLoader loader = WarriorsFishingBridge.class.getClassLoader();
/* 205 */     Class<?> client = Class.forName("com.nonopichy.yggdrasilremake.client.warriors.pesca.PescaClient", false, loader);
/* 206 */     Class<?> sessionType = Class.forName("com.nonopichy.yggdrasilremake.client.warriors.pesca.PescaClient$Sessao", false, loader);
/* 207 */     Class<?> playerType = Class.forName("com.nonopichy.yggdrasilremake.client.warriors.pesca.Pescador", false, loader);
/* 208 */     Class<?> rulesType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaPacotes$SessaoS2C", false, loader);
/* 209 */     Class<?> pointType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaPacotes$Ponto", false, loader);
/* 210 */     Class<?> packetType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaPacotes$AcaoC2S", false, loader);
/* 211 */     Class<?> networkType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.WarriorsNet", false, loader);
/* 212 */     Class<?> gameRulesType = Class.forName("com.nonopichy.yggdrasilremake.common.warriors.net.PescaRegras", false, loader);
/* 213 */     Field protocol = field(gameRulesType, "VERSAO", int.class, true);
/* 214 */     if (!Modifier.isFinal(protocol.getModifiers()) || protocol.getInt((Object)null) != 2)
/* 215 */       throw new IllegalStateException("Protocolo de pesca diferente de 2"); 
/* 216 */     this.session = field(client, "sessao", sessionType, true);
/* 217 */     this.nearbyPoint = field(client, "pontoPerto", pointType, true);
/* 218 */     this.lastStart = field(client, "ultimoIniciar", long.class, true);
/* 219 */     this.playerState = field(sessionType, "ps", playerType, false);
/* 220 */     this.rules = field(sessionType, "regras", rulesType, false);
/* 221 */     this.phase = field(playerType, "fase", byte.class, false);
/* 222 */     this.sequence = field(sessionType, "seq", int.class, false);
/* 223 */     this.hits = field(sessionType, "acertos", int.class, false);
/* 224 */     this.errors = field(sessionType, "erros", int.class, false);
/* 225 */     this.attracted = field(sessionType, "atraidos", int.class, false);
/* 226 */     this.grade = field(sessionType, "nota", byte.class, false);
/* 227 */     this.escaped = field(sessionType, "escapou", boolean.class, false);
/* 228 */     this.won = field(sessionType, "ganhou", boolean.class, false);
/* 229 */     this.lastClick = field(sessionType, "ultimoClique", long.class, false);
/* 230 */     this.finishAt = field(sessionType, "fimEm", long.class, false);
/* 231 */     this.biteAt = field(sessionType, "mordidaEm", long.class, false);
/* 232 */     this.click = method(client, "clicar", boolean.class, true, new Class[0]);
/* 233 */     this.marker = method(client, "marcador", float.class, true, new Class[0]);
/* 234 */     this.inZone = method(client, "naZona", boolean.class, true, new Class[] { float.class });
/* 235 */     this.circleProgress = method(client, "progressoDaMira", double.class, true, new Class[0]);
/* 236 */     this.clock = method(client, "relogio", long.class, true, new Class[0]);
/* 237 */     this.phaseTime = method(playerType, "t", double.class, false, new Class[0]);
/* 238 */     this.sessionId = method(rulesType, "sessao", int.class, false, new Class[0]);
/* 239 */     this.requiredHits = method(rulesType, "acertos", byte.class, false, new Class[0]);
/* 240 */     this.allowedErrors = method(rulesType, "erros", byte.class, false, new Class[0]);
/* 241 */     this.findPoint = method(client, "procurarPonto", void.class, true, new Class[] { Minecraft.class });
/* 242 */     this.pointId = method(pointType, "id", String.class, false, new Class[0]);
/* 243 */     this.pointUnlocked = method(pointType, "liberado", boolean.class, false, new Class[0]);
/* 244 */     this.pointOccupied = method(client, "ocupado", boolean.class, true, new Class[] { pointType });
/* 245 */     this.sendToServer = method(networkType, "sendToServer", void.class, true, new Class[] { Object.class });
/* 246 */     this.changePhase = method(client, "mudar", void.class, true, new Class[] { byte.class });
/* 247 */     this.startPacket = packetType.getDeclaredConstructor(new Class[] { byte.class, int.class, String.class, byte.class, byte.class, int.class });
/* 248 */     if (!this.startPacket.trySetAccessible()) throw new IllegalAccessException("Construtor do pedido de pesca inacessivel"); 
/*     */   }
/*     */   
/*     */   private static Field field(Class<?> owner, String name, Class<?> type, boolean isStatic) throws ReflectiveOperationException {
/* 252 */     Field field = owner.getDeclaredField(name);
/* 253 */     if (field.getType() != type || Modifier.isStatic(field.getModifiers()) != isStatic || !field.trySetAccessible())
/* 254 */       throw new NoSuchFieldException(owner.getSimpleName() + "." + owner.getSimpleName() + " incompativel"); 
/* 255 */     return field;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Method method(Class<?> owner, String name, Class<?> result, boolean isStatic, Class<?>... params) throws ReflectiveOperationException {
/* 260 */     Method method = owner.getDeclaredMethod(name, params);
/* 261 */     if (method.getReturnType() != result || Modifier.isStatic(method.getModifiers()) != isStatic || !method.trySetAccessible())
/* 262 */       throw new NoSuchMethodException(owner.getSimpleName() + "." + owner.getSimpleName() + " incompativel"); 
/* 263 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\WarriorsFishingBridge$Access.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */