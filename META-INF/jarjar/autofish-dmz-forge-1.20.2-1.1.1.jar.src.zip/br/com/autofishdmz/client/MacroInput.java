/*     */ package br.com.autofishdmz.client;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.InputConstants;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.client.KeyMapping;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MacroInput
/*     */ {
/*     */   private static final double LEFT_DURATION = 0.025D;
/*     */   private static final double RIGHT_DURATION = 0.012D;
/*     */   private static final double SHIFT_DURATION = 0.08D;
/*     */   private final Minecraft minecraft;
/*  23 */   private final boolean[] mouseOwned = new boolean[2];
/*  24 */   private final double[] mouseReleaseAt = new double[2];
/*     */   private boolean shiftOwned;
/*     */   private double shiftReleaseAt;
/*     */   
/*     */   public MacroInput(Minecraft minecraft) {
/*  29 */     this.minecraft = Objects.<Minecraft>requireNonNull(minecraft, "minecraft");
/*     */   }
/*     */   
/*     */   public void leftClick() {
/*  33 */     pressMouse(0, 0.025D);
/*     */   }
/*     */   
/*     */   public void rightClick() {
/*  37 */     pressMouse(1, 0.012D);
/*     */   }
/*     */   
/*     */   public void tapShift() {
/*  41 */     if (this.shiftOwned || physicalKey(340) || 
/*  42 */       physicalKey(344)) {
/*     */       return;
/*     */     }
/*  45 */     this.shiftOwned = true;
/*  46 */     this.shiftReleaseAt = seconds() + 0.08D;
/*  47 */     this.minecraft.f_91068_.m_90893_(window(), 340, 
/*  48 */         GLFW.glfwGetKeyScancode(340), 1, 
/*  49 */         modifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public void pump(double now) {
/*  54 */     for (int button = 0; button < this.mouseOwned.length; button++) {
/*  55 */       if (this.mouseOwned[button] && now >= this.mouseReleaseAt[button]) {
/*  56 */         releaseMouse(button);
/*     */       }
/*     */     } 
/*  59 */     if (this.shiftOwned && now >= this.shiftReleaseAt) {
/*  60 */       releaseShift();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void releaseAll() {
/*  66 */     for (int button = 0; button < this.mouseOwned.length; button++) {
/*  67 */       if (this.mouseOwned[button]) {
/*  68 */         releaseMouse(button);
/*     */       }
/*     */     } 
/*  71 */     if (this.shiftOwned) {
/*  72 */       releaseShift();
/*     */     }
/*     */   }
/*     */   
/*     */   private void pressMouse(int button, double duration) {
/*  77 */     if (this.mouseOwned[button] || physicalMouse(button)) {
/*     */       return;
/*     */     }
/*  80 */     this.mouseOwned[button] = true;
/*  81 */     this.mouseReleaseAt[button] = seconds() + duration;
/*  82 */     this.minecraft.f_91067_.m_91530_(window(), button, 1, modifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void releaseMouse(int button) {
/*  88 */     this.mouseOwned[button] = false;
/*  89 */     if (!physicalMouse(button)) {
/*     */       try {
/*  91 */         this.minecraft.f_91067_.m_91530_(window(), button, 0, modifiers());
/*     */       
/*     */       }
/*     */       finally {
/*     */ 
/*     */         
/*  97 */         if (!physicalMouse(button)) {
/*  98 */           if (button == 0) {
/*  99 */             this.minecraft.f_91067_.f_91504_ = false;
/* 100 */           } else if (button == 1) {
/* 101 */             this.minecraft.f_91067_.f_91506_ = false;
/*     */           } 
/* 103 */           KeyMapping.m_90837_(InputConstants.Type.MOUSE.m_84895_(button), false);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void releaseShift() {
/* 110 */     this.shiftOwned = false;
/* 111 */     if (!physicalKey(340)) {
/* 112 */       this.minecraft.f_91068_.m_90893_(window(), 340, 
/* 113 */           GLFW.glfwGetKeyScancode(340), 0, 
/* 114 */           modifiers());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean physicalMouse(int button) {
/* 119 */     return (GLFW.glfwGetMouseButton(window(), button) == 1);
/*     */   }
/*     */   
/*     */   private boolean physicalKey(int key) {
/* 123 */     return (GLFW.glfwGetKey(window(), key) == 1);
/*     */   }
/*     */   
/*     */   private int modifiers() {
/* 127 */     int flags = 0;
/* 128 */     if (this.shiftOwned || physicalKey(340) || 
/* 129 */       physicalKey(344)) flags |= 0x1; 
/* 130 */     if (physicalKey(341) || 
/* 131 */       physicalKey(345)) flags |= 0x2; 
/* 132 */     if (physicalKey(342) || 
/* 133 */       physicalKey(346)) flags |= 0x4; 
/* 134 */     if (physicalKey(343) || 
/* 135 */       physicalKey(347)) flags |= 0x8; 
/* 136 */     return flags;
/*     */   }
/*     */   
/*     */   private long window() {
/* 140 */     return this.minecraft.m_91268_().m_85439_();
/*     */   }
/*     */   
/*     */   private static double seconds() {
/* 144 */     return System.nanoTime() / 1.0E9D;
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\MacroInput.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */