/*    */ package br.com.autofishdmz.client;
/*    */ 
/*    */ import br.com.autofishdmz.core.FishingEngine;
/*    */ import com.mojang.logging.LogUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements FishingEngine.Actions
/*    */ {
/*    */   public void leftClick() {
/* 23 */     ClientController.this.input.leftClick();
/* 24 */   } public void rightClick() { ClientController.this.input.rightClick(); }
/* 25 */   public void tapShift() { ClientController.this.input.tapShift(); } public void releaseAll() {
/* 26 */     ClientController.this.input.releaseAll();
/*    */   } public void log(String message) {
/* 28 */     LogUtils.getLogger().info("[AutoFish DMZ] {}", message);
/* 29 */     if (ClientController.this.config.debug_record) ClientController.this.debug.log(message); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\ClientController$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */