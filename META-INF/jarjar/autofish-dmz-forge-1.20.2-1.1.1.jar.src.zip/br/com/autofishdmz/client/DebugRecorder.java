/*     */ package br.com.autofishdmz.client;
/*     */ import br.com.autofishdmz.core.Detection;
/*     */ import br.com.autofishdmz.core.NativeFishingSnapshot;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.mojang.logging.LogUtils;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.OpenOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardOpenOption;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.stream.Stream;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.minecraftforge.fml.loading.FMLPaths;
/*     */ 
/*     */ final class DebugRecorder {
/*     */   DebugRecorder() {
/*  25 */     this.writer = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(4), runnable -> { Thread thread = new Thread(runnable, "AutoFish-debug"); thread.setDaemon(true); return thread; }new ThreadPoolExecutor.DiscardPolicy());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  32 */     this.lastActive = Double.NEGATIVE_INFINITY; this.lastSave = Double.NEGATIVE_INFINITY;
/*     */   }
/*     */   static final Path ROOT = FMLPaths.GAMEDIR.get().resolve("autofish-dmz-debug"); private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"); private final ThreadPoolExecutor writer; private String session; private double lastActive; private double lastSave; private int frameCount;
/*     */   void nativeSnapshot(NativeFishingSnapshot snapshot) {
/*  36 */     String json = (new GsonBuilder()).setPrettyPrinting().create().toJson(snapshot);
/*  37 */     String name = "dbg-native-" + STAMP.format(LocalDateTime.now()) + ".json";
/*  38 */     this.writer.execute(() -> {
/*     */           try {
/*     */             Files.createDirectories(ROOT, (FileAttribute<?>[])new FileAttribute[0]);
/*     */             Files.writeString(ROOT.resolve(name), json, StandardCharsets.UTF_8, new OpenOption[0]);
/*     */             prune();
/*  43 */           } catch (Exception e) {
/*     */             LogUtils.getLogger().warn("AutoFish: falha ao salvar estado da pesca", e);
/*     */           } 
/*     */         });
/*     */   } void frame(FrameCapture capture, Detection detection, double now, boolean enabled, boolean manual) {
/*  48 */     if (manual) {
/*  49 */       enqueue(capture.snapshot(), "dbg-" + STAMP.format(LocalDateTime.now()), detection);
/*     */       return;
/*     */     } 
/*  52 */     if (!enabled)
/*  53 */       return;  boolean minigame = (detection.arc() || detection.arcBar() || detection.circle() || detection.circleVisible());
/*  54 */     if (minigame) {
/*  55 */       if (this.session == null || now - this.lastActive > 2.5D) {
/*  56 */         this.session = "peixe-" + STAMP.format(LocalDateTime.now());
/*  57 */         this.frameCount = 0;
/*     */       } 
/*  59 */       this.lastActive = now;
/*     */     } 
/*  61 */     if (this.session == null || now - this.lastActive > 2.5D || this.frameCount >= 60 || now - this.lastSave < 0.06D || this.writer
/*  62 */       .getQueue().remainingCapacity() == 0)
/*  63 */       return;  this.lastSave = now;
/*  64 */     this.frameCount++;
/*  65 */     enqueue(capture.snapshot(), this.session + "-" + this.session, detection);
/*     */   }
/*     */   
/*     */   void log(String message) {
/*  69 */     this.writer.execute(() -> {
/*     */           try {
/*     */             Files.createDirectories(ROOT, (FileAttribute<?>[])new FileAttribute[0]);
/*     */             Path log = ROOT.resolve("atividade.log");
/*     */             if (Files.exists(log, new java.nio.file.LinkOption[0]) && Files.size(log) > 262144L)
/*     */               Files.delete(log); 
/*     */             Files.writeString(log, String.valueOf(LocalDateTime.now()) + " " + String.valueOf(LocalDateTime.now()) + message, StandardCharsets.UTF_8, new OpenOption[] { StandardOpenOption.CREATE, StandardOpenOption.APPEND });
/*  76 */           } catch (Exception e) {
/*     */             LogUtils.getLogger().warn("AutoFish: falha no log de debug", e);
/*     */           } 
/*     */         });
/*     */   } private void enqueue(BufferedImage image, String name, Detection detection) {
/*  81 */     String json = (new GsonBuilder()).setPrettyPrinting().create().toJson(detection);
/*  82 */     this.writer.execute(() -> {
/*     */           try {
/*     */             Files.createDirectories(ROOT, (FileAttribute<?>[])new FileAttribute[0]);
/*     */             ImageIO.write(image, "jpg", ROOT.resolve(name + ".jpg").toFile());
/*     */             Files.writeString(ROOT.resolve(name + ".json"), json, StandardCharsets.UTF_8, new OpenOption[0]);
/*     */             prune();
/*  88 */           } catch (Exception e) {
/*     */             LogUtils.getLogger().warn("AutoFish: falha ao salvar debug", e);
/*     */           } 
/*     */         });
/*     */   } private void prune() throws IOException {
/*     */     List<Path> files;
/*  94 */     Stream<Path> stream = Files.list(ROOT);
/*     */ 
/*     */ 
/*     */     
/*  98 */     try { files = stream.filter(x$0 -> Files.isRegularFile(x$0, new java.nio.file.LinkOption[0])).filter(path -> { String name = path.getFileName().toString(); return ((name.startsWith("peixe-") || name.startsWith("dbg-")) && (name.endsWith(".jpg") || name.endsWith(".json"))); }).sorted(Comparator.comparingLong(DebugRecorder::modified)).toList();
/*  99 */       if (stream != null) stream.close();  } catch (Throwable throwable) { if (stream != null)
/* 100 */         try { stream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  long bytes = 0L;
/* 101 */     for (Path file : files) bytes += Files.size(file); 
/* 102 */     if (bytes <= 10485760L)
/* 103 */       return;  for (Path file : files) {
/* 104 */       bytes -= Files.size(file);
/* 105 */       Files.deleteIfExists(file);
/* 106 */       if (bytes <= 8388608L)
/*     */         break; 
/*     */     } 
/*     */   } private static long modified(Path file) {
/*     */     
/* 111 */     try { return Files.getLastModifiedTime(file, new java.nio.file.LinkOption[0]).toMillis(); } catch (Exception e) { return 0L; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\DebugRecorder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */