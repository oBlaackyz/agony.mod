/*     */ package br.com.autofishdmz.client;
/*     */ import br.com.autofishdmz.core.BotConfig;
/*     */ import br.com.autofishdmz.core.Detection;
/*     */ import br.com.autofishdmz.core.FishingDetector;
/*     */ import br.com.autofishdmz.core.FishingEngine;
/*     */ import br.com.autofishdmz.core.NativeFishingEngine;
/*     */ import br.com.autofishdmz.core.NativeFishingSnapshot;
/*     */ import com.mojang.blaze3d.pipeline.RenderTarget;
/*     */ import com.mojang.logging.LogUtils;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ public final class ClientController {
/*     */   private static ClientController instance;
/*  17 */   private final Minecraft minecraft = Minecraft.m_91087_();
/*  18 */   private final MacroInput input = new MacroInput(this.minecraft);
/*  19 */   private final FrameCapture capture = new FrameCapture();
/*  20 */   private final DebugRecorder debug = new DebugRecorder();
/*  21 */   private BotConfig config = ConfigStore.load();
/*  22 */   private final FishingEngine engine = new FishingEngine(this.config, new FishingEngine.Actions() {
/*  23 */         public void leftClick() { ClientController.this.input.leftClick(); }
/*  24 */         public void rightClick() { ClientController.this.input.rightClick(); }
/*  25 */         public void tapShift() { ClientController.this.input.tapShift(); } public void releaseAll() {
/*  26 */           ClientController.this.input.releaseAll();
/*     */         } public void log(String message) {
/*  28 */           LogUtils.getLogger().info("[AutoFish DMZ] {}", message);
/*  29 */           if (ClientController.this.config.debug_record) ClientController.this.debug.log(message); 
/*     */         }
/*     */       });
/*  32 */   private final WarriorsFishingBridge bridge = WarriorsFishingBridge.create();
/*  33 */   private final NativeFishingEngine nativeEngine = new NativeFishingEngine(this.config, new NativeFishingEngine.Actions() {
/*  34 */         public boolean start() { return ClientController.this.bridge.start(); }
/*  35 */         public boolean click() { return ClientController.this.bridge.click(); } public boolean cancel() {
/*  36 */           return ClientController.this.bridge.cancel();
/*     */         } public void log(String message) {
/*  38 */           LogUtils.getLogger().info("[AutoFish DMZ / segundo plano] {}", message);
/*  39 */           if (ClientController.this.config.debug_record) ClientController.this.debug.log(message); 
/*     */         }
/*     */       });
/*     */   private FishingDetector detector; private int detectorWidth; private int detectorHeight;
/*     */   private double detectorScale;
/*  44 */   private double lastFrame = Double.NEGATIVE_INFINITY;
/*  45 */   private double lastNativeUpdate = Double.NEGATIVE_INFINITY;
/*     */   private boolean debugRequested;
/*     */   private boolean inWorld;
/*  48 */   private String status = "Pausado"; private double activeSeconds;
/*  49 */   private double lastElapsed = now();
/*     */ 
/*     */   
/*     */   public static ClientController get() {
/*  53 */     if (instance == null) instance = new ClientController(); 
/*  54 */     return instance;
/*     */   }
/*  56 */   public BotConfig config() { return this.config; }
/*  57 */   public FishingEngine engine() { return this.engine; }
/*  58 */   public boolean nativeMode() { return (this.config.background_mode && this.bridge.available()); }
/*  59 */   public boolean running() { return nativeMode() ? this.nativeEngine.running() : this.engine.running(); } public int catches() {
/*  60 */     return this.engine.catches() + this.nativeEngine.catches();
/*     */   }
/*     */   public void saveConfig(BotConfig candidate) throws IOException {
/*  63 */     boolean previousNative = nativeMode();
/*  64 */     boolean wasRunning = running();
/*  65 */     ConfigStore.save(candidate);
/*  66 */     this.config = candidate;
/*  67 */     this.engine.configure(this.config, now());
/*  68 */     this.nativeEngine.configure(this.config, now());
/*  69 */     if (previousNative != nativeMode()) {
/*  70 */       this.engine.stop(now());
/*  71 */       this.nativeEngine.stop(now());
/*  72 */       if (wasRunning)
/*  73 */         if (nativeMode()) { this.nativeEngine.toggle(now()); } else { this.engine.toggle(now()); }
/*     */          
/*     */     } 
/*  76 */     this.detector = null;
/*     */   }
/*     */   
/*     */   public void toggle() {
/*  80 */     if (this.minecraft.f_91074_ == null || this.minecraft.f_91073_ == null)
/*  81 */       return;  this.input.releaseAll();
/*  82 */     if (nativeMode()) { this.nativeEngine.toggle(now()); } else { this.engine.toggle(now()); }
/*  83 */      this.status = running() ? "Preparando pesca" : "Pausado";
/*  84 */     message(running() ? (nativeMode() ? 
/*  85 */         "Ligado em segundo plano. Pode usar Esc, Alt+Tab ou minimizar. F6 pausa." : 
/*  86 */         "Ligado no modo visual. F6 pausa; F7 abre ajustes.") : "Pausado.");
/*  87 */     if (running() && this.config.background_mode && !this.bridge.available()) {
/*  88 */       message("Integracao Warriors indisponivel; modo visual exige jogo visivel. Consulte latest.log.");
/*  89 */       LogUtils.getLogger().warn("AutoFish: {}", this.bridge.unavailableReason());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/*  94 */     this.engine.stop(now());
/*  95 */     this.nativeEngine.stop(now());
/*  96 */     this.status = "Desligado";
/*  97 */     this.capture.close();
/*  98 */     message("Desligado. F6 liga novamente.");
/*     */   }
/*     */   public void requestDebug() {
/* 101 */     this.debugRequested = true;
/*     */   }
/*     */   public void tick() {
/* 104 */     double time = now();
/* 105 */     this.input.pump(time);
/* 106 */     if (this.minecraft.f_91074_ == null || this.minecraft.f_91073_ == null) {
/* 107 */       if (this.engine.running()) this.engine.stop(time); 
/* 108 */       if (this.inWorld || this.nativeEngine.running()) this.nativeEngine.disconnect(time); 
/* 109 */       this.inWorld = false;
/* 110 */       this.capture.close();
/* 111 */       this.debugRequested = false;
/* 112 */       this.status = "Fora do mundo";
/*     */     } else {
/* 114 */       this.inWorld = true;
/* 115 */       if (nativeMode()) {
/* 116 */         updateNative(time);
/* 117 */       } else if (!canAct()) {
/* 118 */         this.engine.suspend(time);
/* 119 */         if (this.engine.running()) this.status = "Aguardando foco / fechar menu";
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void frame() {
/* 126 */     double time = now();
/* 127 */     this.input.pump(time);
/* 128 */     if (nativeMode()) {
/* 129 */       updateNative(time);
/*     */       return;
/*     */     } 
/* 132 */     trackElapsed(time, (this.engine.running() && canAct()));
/* 133 */     if (this.minecraft.f_91074_ == null || this.minecraft.f_91073_ == null)
/* 134 */       return;  if (!canAct()) {
/* 135 */       this.engine.suspend(time);
/* 136 */       if (this.engine.running()) this.status = "Aguardando foco / fechar menu"; 
/*     */       return;
/*     */     } 
/* 139 */     if (!this.engine.running() && !this.debugRequested)
/* 140 */       return;  if (!this.debugRequested && time - this.lastFrame < 0.008333333333333333D)
/* 141 */       return;  this.lastFrame = time;
/*     */     try {
/* 143 */       RenderTarget target = this.minecraft.m_91385_();
/* 144 */       int width = target.f_83917_, height = target.f_83918_;
/* 145 */       if (width < 320 || height < 240) { this.engine.suspend(time); return; }
/* 146 */        double scale = this.config.auto_scale ? (height / 1008.0D) : this.config.manual_scale;
/* 147 */       if (this.detector == null || this.detectorWidth != width || this.detectorHeight != height || this.detectorScale != scale) {
/* 148 */         this.detectorWidth = width; this.detectorHeight = height; this.detectorScale = scale;
/* 149 */         this.detector = new FishingDetector(width, height, scale, this.config.circle_trigger_radius);
/*     */       } 
/* 151 */       this.capture.read(target, scale);
/* 152 */       Detection detection = this.detector.analyze(this.capture);
/* 153 */       this.debug.frame(this.capture, detection, time, (this.config.debug_record && this.engine.running()), this.debugRequested);
/* 154 */       if (this.debugRequested) { this.debugRequested = false; message("Debug solicitado em " + String.valueOf(DebugRecorder.ROOT.getFileName())); }
/* 155 */        if (this.engine.running()) {
/* 156 */         this.engine.update(detection, time);
/* 157 */         this.status = stateLabel(this.engine.state());
/*     */       } 
/* 159 */     } catch (Exception e) {
/* 160 */       this.engine.stop(time);
/* 161 */       this.debugRequested = false;
/* 162 */       this.capture.close();
/* 163 */       this.status = "Erro: consulte latest.log";
/* 164 */       LogUtils.getLogger().error("AutoFish interrompido por erro", e);
/* 165 */       message(this.status);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateNative(double time) {
/* 172 */     boolean canRun = (this.minecraft.f_91074_ != null && this.minecraft.f_91073_ != null && this.minecraft.m_91403_() != null && this.minecraft.f_91074_.m_6084_() && !this.minecraft.m_91104_() && this.minecraft.m_91265_() == null && !(this.minecraft.f_91080_ instanceof AutoFishScreen));
/*     */     
/* 174 */     trackElapsed(time, (this.nativeEngine.running() && canRun));
/* 175 */     if (!canRun) {
/* 176 */       this.nativeEngine.suspend(time);
/* 177 */       if (this.nativeEngine.running()) this.status = "Aguardando jogo / fechar ajustes"; 
/*     */       return;
/*     */     } 
/* 180 */     if (!this.nativeEngine.running() && !this.debugRequested)
/*     */       return; 
/* 182 */     if (!this.debugRequested && time - this.lastNativeUpdate < 0.008333333333333333D)
/* 183 */       return;  this.lastNativeUpdate = time;
/*     */     try {
/* 185 */       NativeFishingSnapshot snapshot = this.bridge.sample();
/* 186 */       if (this.debugRequested) {
/* 187 */         this.debugRequested = false;
/* 188 */         this.debug.nativeSnapshot(snapshot);
/* 189 */         message("Estado da pesca solicitado em " + String.valueOf(DebugRecorder.ROOT.getFileName()));
/*     */       } 
/* 191 */       if (this.nativeEngine.running()) {
/* 192 */         this.nativeEngine.update(snapshot, time);
/* 193 */         this.status = stateLabel(this.nativeEngine.state());
/*     */       } 
/* 195 */     } catch (RuntimeException e) {
/* 196 */       this.nativeEngine.stop(time);
/* 197 */       this.input.releaseAll();
/* 198 */       this.debugRequested = false;
/* 199 */       this.status = "Erro na integracao Warriors";
/* 200 */       LogUtils.getLogger().error("AutoFish: integracao interrompida; nenhuma acao adicional sera enviada", e);
/* 201 */       message(this.status + ". Consulte latest.log; F7 permite voltar ao modo visual.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void trackElapsed(double time, boolean active) {
/* 206 */     if (active) this.activeSeconds += Math.min(1.0D, Math.max(0.0D, time - this.lastElapsed)); 
/* 207 */     this.lastElapsed = time;
/*     */   }
/*     */   
/*     */   private boolean canAct() {
/* 211 */     if (!this.minecraft.m_91302_() || this.minecraft.f_91080_ != null || this.minecraft.m_91265_() != null || this.minecraft
/* 212 */       .m_91104_() || this.minecraft.f_91066_.f_92062_ || this.minecraft.f_91074_ == null || 
/* 213 */       !this.minecraft.f_91074_.m_6084_()) return false; 
/* 214 */     long window = this.minecraft.m_91268_().m_85439_();
/*     */     
/* 216 */     return (GLFW.glfwGetMouseButton(window, 0) != 1 && 
/* 217 */       GLFW.glfwGetMouseButton(window, 1) != 1 && 
/* 218 */       GLFW.glfwGetKey(window, 340) != 1 && 
/* 219 */       GLFW.glfwGetKey(window, 344) != 1);
/*     */   }
/*     */   
/*     */   public void hud(GuiGraphics graphics) {
/* 223 */     if (!this.config.show_hud || this.minecraft.f_91074_ == null || this.minecraft.f_91080_ != null || this.minecraft.f_91066_.f_92062_)
/* 224 */       return;  String title = "AutoFish DMZ | " + (running() ? "LIGADO" : "PAUSADO");
/*     */     
/* 226 */     String details = "Peixes: " + catches() + " | " + formatTime((long)this.activeSeconds) + (nativeMode() ? " | 2o plano" : " | Visual");
/* 227 */     int width = Math.max(188, Math.max(this.minecraft.f_91062_.m_92895_(this.status), this.minecraft.f_91062_.m_92895_(details)) + 16);
/* 228 */     graphics.m_280509_(6, 6, 6 + width, 62, -1072358363);
/* 229 */     graphics.m_280509_(6, 6, 8, 62, running() ? -12331359 : -934557);
/* 230 */     graphics.m_280488_(this.minecraft.f_91062_, title, 14, 12, running() ? -10230082 : -11657);
/* 231 */     graphics.m_280488_(this.minecraft.f_91062_, this.status, 14, 25, -1445898);
/* 232 */     graphics.m_280488_(this.minecraft.f_91062_, details, 14, 37, -3944484);
/* 233 */     graphics.m_280488_(this.minecraft.f_91062_, "                          ", 14, 49, -7426875);
/*     */   }
/*     */   
/*     */   private void message(String text) {
/* 237 */     if (this.minecraft.f_91074_ != null) this.minecraft.f_91074_.m_5661_((Component)Component.m_237113_("[AutoFish DMZ] " + text), false); 
/*     */   }
/*     */   public static String stateLabel(String state) {
/* 240 */     switch (state) { case "IDLE": case "CAST": case "ATTRACT": case "BITE_WAIT": case "ARC": case "CIRCLE": case "CONFIRM": case "WAIT":  }  return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 249 */       state;
/*     */   }
/*     */   
/*     */   private static String formatTime(long seconds) {
/* 253 */     return String.format("%02d:%02d:%02d", new Object[] { Long.valueOf(seconds / 3600L), Long.valueOf(seconds / 60L % 60L), Long.valueOf(seconds % 60L) });
/*     */   } private static double now() {
/* 255 */     return System.nanoTime() / 1.0E9D;
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\ClientController.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */