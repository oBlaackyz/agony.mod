/*    */ package br.com.autofishdmz.client;
/*    */ 
/*    */ import br.com.autofishdmz.core.NativeFishingEngine;
/*    */ import com.mojang.logging.LogUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements NativeFishingEngine.Actions
/*    */ {
/*    */   public boolean start() {
/* 34 */     return ClientController.this.bridge.start();
/* 35 */   } public boolean click() { return ClientController.this.bridge.click(); } public boolean cancel() {
/* 36 */     return ClientController.this.bridge.cancel();
/*    */   } public void log(String message) {
/* 38 */     LogUtils.getLogger().info("[AutoFish DMZ / segundo plano] {}", message);
/* 39 */     if (ClientController.this.config.debug_record) ClientController.this.debug.log(message); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\client\ClientController$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */