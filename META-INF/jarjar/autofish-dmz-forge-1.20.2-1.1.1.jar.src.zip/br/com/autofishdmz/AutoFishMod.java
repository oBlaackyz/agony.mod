package br.com.autofishdmz;

import net.minecraftforge.fml.common.Mod;

@Mod("autofishdmz")
public final class AutoFishMod {
  public static final String ID = "autofishdmz";
}


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\AutoFishMod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */