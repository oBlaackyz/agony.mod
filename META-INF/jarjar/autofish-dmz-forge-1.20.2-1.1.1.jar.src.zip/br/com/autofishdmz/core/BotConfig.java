/*    */ package br.com.autofishdmz.core;
/*    */ 
/*    */ public final class BotConfig
/*    */ {
/*  5 */   public double attract_interval = 0.22D;
/*  6 */   public double cast_retry_interval = 0.02D;
/*  7 */   public double cast_timeout = 12.0D;
/*  8 */   public double attract_timeout = 60.0D;
/*    */   public boolean allow_shift_reset = false;
/* 10 */   public double confirm_delay = 1.5D;
/* 11 */   public int confirm_clicks = 1;
/* 12 */   public double circle_trigger_radius = 76.0D;
/* 13 */   public double circle_latency = 0.06D;
/*    */   
/*    */   public boolean always_on_top = true;
/*    */   public boolean auto_scale = true;
/* 17 */   public double manual_scale = 1.0D;
/*    */   
/*    */   public boolean debug_record = true;
/*    */   
/*    */   public boolean show_hud = true;
/*    */   public boolean background_mode = true;
/* 23 */   public double arc_hit_cooldown = 0.3D;
/* 24 */   public double after_catch_wait = 1.0D;
/* 25 */   public double minigame_gone_time = 6.0D;
/* 26 */   public double circle_gone_time = 1.0D;
/* 27 */   public double confirm_click_interval = 0.35D;
/* 28 */   public double recent_minigame_guard = 8.0D;
/* 29 */   public double circle_lost_click_radius = 130.0D;
/*    */ 
/*    */   
/*    */   public void validate() {
/* 33 */     range("attract_interval", this.attract_interval, 0.02D, 30.0D);
/* 34 */     range("cast_retry_interval", this.cast_retry_interval, 0.01D, 30.0D);
/* 35 */     range("cast_timeout", this.cast_timeout, 1.0D, 600.0D);
/* 36 */     range("attract_timeout", this.attract_timeout, 1.0D, 3600.0D);
/* 37 */     range("confirm_delay", this.confirm_delay, 0.0D, 60.0D);
/* 38 */     if (this.confirm_clicks < 1 || this.confirm_clicks > 20) {
/* 39 */       throw new IllegalArgumentException("confirm_clicks deve estar entre 1 e 20");
/*    */     }
/* 41 */     range("circle_trigger_radius", this.circle_trigger_radius, 60.0D, 310.0D);
/* 42 */     range("circle_latency", this.circle_latency, 0.0D, 0.5D);
/* 43 */     range("manual_scale", this.manual_scale, 0.1D, 8.0D);
/* 44 */     range("arc_hit_cooldown", this.arc_hit_cooldown, 0.05D, 5.0D);
/* 45 */     range("after_catch_wait", this.after_catch_wait, 0.1D, 60.0D);
/* 46 */     range("minigame_gone_time", this.minigame_gone_time, 1.0D, 60.0D);
/* 47 */     range("circle_gone_time", this.circle_gone_time, 0.1D, 60.0D);
/* 48 */     range("confirm_click_interval", this.confirm_click_interval, 0.05D, 5.0D);
/* 49 */     range("recent_minigame_guard", this.recent_minigame_guard, 8.0D, 60.0D);
/* 50 */     range("circle_lost_click_radius", this.circle_lost_click_radius, 60.0D, 310.0D);
/*    */   }
/*    */   
/*    */   private static void range(String name, double value, double min, double max) {
/* 54 */     if (!Double.isFinite(value) || value < min || value > max)
/* 55 */       throw new IllegalArgumentException(name + " deve estar entre " + name + " e " + min); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\BotConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */