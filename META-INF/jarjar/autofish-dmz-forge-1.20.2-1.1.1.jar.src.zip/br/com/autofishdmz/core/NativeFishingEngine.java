/*     */ package br.com.autofishdmz.core;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NativeFishingEngine
/*     */ {
/*     */   private BotConfig config;
/*     */   private final Actions actions;
/*     */   private boolean running;
/*     */   private boolean suspended;
/*     */   private boolean hasSession;
/*     */   private long sessionId;
/*     */   private NativeFishingSnapshot.Phase nativePhase;
/*     */   
/*     */   private enum State
/*     */   {
/*  20 */     IDLE, CAST, ATTRACT, BITE_WAIT, ARC, CIRCLE, CONFIRM, WAIT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  26 */   private State state = State.IDLE; private int catches; private int arcHits;
/*     */   private double sessionStarted;
/*     */   private double phaseStarted;
/*  29 */   private double lastClickAttempt = Double.NEGATIVE_INFINITY;
/*  30 */   private double lastStartAttempt = Double.NEGATIVE_INFINITY;
/*  31 */   private double castStarted = Double.NaN;
/*  32 */   private double waitUntil = Double.NEGATIVE_INFINITY;
/*  33 */   private double lastMinigame = Double.NEGATIVE_INFINITY; private boolean minigameSeen; private boolean circleClicked; private boolean resultCounted; private boolean resultConfirmed;
/*     */   private boolean cancelRequested;
/*  35 */   private int acceptedArcSequence = Integer.MIN_VALUE, acceptedArcHits = Integer.MIN_VALUE;
/*  36 */   private int acceptedAttractSequence = Integer.MIN_VALUE;
/*     */   
/*     */   public NativeFishingEngine(BotConfig config, Actions actions) {
/*  39 */     this.config = Objects.<BotConfig>requireNonNull(config, "config");
/*  40 */     this.actions = Objects.<Actions>requireNonNull(actions, "actions");
/*  41 */     config.validate();
/*     */   }
/*     */   
/*  44 */   public boolean running() { return this.running; }
/*  45 */   public boolean suspended() { return this.suspended; }
/*  46 */   public String state() { return this.state.name(); }
/*  47 */   public int catches() { return this.catches; } public int arcHits() {
/*  48 */     return this.arcHits;
/*     */   }
/*     */   public void configure(BotConfig config, double now) {
/*  51 */     ((BotConfig)Objects.<BotConfig>requireNonNull(config, "config")).validate();
/*  52 */     requireTime(now);
/*  53 */     this.config = config;
/*  54 */     suspend(now);
/*     */   }
/*     */   
/*     */   public void toggle(double now) {
/*  58 */     requireTime(now);
/*  59 */     if (this.running) {
/*  60 */       stop(now);
/*     */     } else {
/*  62 */       this.running = true;
/*  63 */       this.suspended = false;
/*  64 */       this.castStarted = Double.NaN;
/*  65 */       this.waitUntil = Double.NEGATIVE_INFINITY;
/*  66 */       this.actions.log("LIGADO (controle nativo em segundo plano)");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop(double now) {
/*  71 */     requireTime(now);
/*  72 */     this.running = false;
/*  73 */     this.suspended = false;
/*  74 */     this.castStarted = Double.NaN;
/*  75 */     setState(State.IDLE);
/*     */ 
/*     */     
/*  78 */     this.actions.log("PAUSADO (controle nativo)");
/*     */   }
/*     */ 
/*     */   
/*     */   public void disconnect(double now) {
/*  83 */     stop(now);
/*  84 */     this.hasSession = false;
/*  85 */     this.sessionId = 0L;
/*  86 */     this.nativePhase = null;
/*  87 */     this.sessionStarted = this.phaseStarted = 0.0D;
/*  88 */     this.minigameSeen = this.circleClicked = this.resultCounted = this.resultConfirmed = this.cancelRequested = false;
/*  89 */     this.acceptedArcSequence = this.acceptedArcHits = this.acceptedAttractSequence = Integer.MIN_VALUE;
/*  90 */     this.lastClickAttempt = this.lastStartAttempt = this.lastMinigame = this.waitUntil = Double.NEGATIVE_INFINITY;
/*  91 */     this.arcHits = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void suspend(double now) {
/*  96 */     requireTime(now);
/*  97 */     this.suspended = true;
/*     */   }
/*     */   public void update(NativeFishingSnapshot snapshot, double now) {
/*     */     boolean fresh;
/* 101 */     Objects.requireNonNull(snapshot, "snapshot");
/* 102 */     requireTime(now);
/* 103 */     if (!this.running)
/* 104 */       return;  this.suspended = false;
/*     */     
/* 106 */     if (snapshot.phase() == NativeFishingSnapshot.Phase.IDLE) {
/* 107 */       idle(now);
/*     */       return;
/*     */     } 
/* 110 */     observeSession(snapshot, now);
/* 111 */     if (snapshot.phase() != this.nativePhase) {
/* 112 */       this.nativePhase = snapshot.phase();
/* 113 */       this.phaseStarted = now;
/*     */     } 
/* 115 */     this.arcHits = snapshot.arcHits();
/*     */     
/* 117 */     switch (snapshot.phase()) {
/*     */       case CAST:
/* 119 */         setState(State.CAST);
/* 120 */         resetIfTimedOut(now, this.config.cast_timeout);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case ATTRACT:
/* 126 */         if (snapshot.bitePending()) {
/* 127 */           setState(State.BITE_WAIT);
/*     */           return;
/*     */         } 
/* 130 */         setState(State.ATTRACT);
/* 131 */         if (resetIfTimedOut(now, this.config.attract_timeout))
/* 132 */           return;  if (snapshot.sequence() != this.acceptedAttractSequence && now - this.lastClickAttempt > this.config.attract_interval) {
/*     */           
/* 134 */           this.lastClickAttempt = now;
/* 135 */           if (this.actions.click()) this.acceptedAttractSequence = snapshot.sequence(); 
/*     */         } 
/*     */         break;
/*     */       case ARC:
/* 139 */         setState(State.ARC);
/* 140 */         this.minigameSeen = true;
/* 141 */         this.lastMinigame = now;
/* 142 */         fresh = (snapshot.sequence() != this.acceptedArcSequence || snapshot.arcHits() != this.acceptedArcHits);
/* 143 */         if (fresh && snapshot.arcReady() && now - this.lastClickAttempt > this.config.arc_hit_cooldown) {
/* 144 */           this.lastClickAttempt = now;
/* 145 */           if (this.actions.click()) {
/* 146 */             this.acceptedArcSequence = snapshot.sequence();
/* 147 */             this.acceptedArcHits = snapshot.arcHits();
/* 148 */             this.actions.log("arco: clique nativo aceito");
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case CIRCLE:
/* 153 */         setState(State.CIRCLE);
/* 154 */         this.minigameSeen = true;
/* 155 */         this.lastMinigame = now;
/* 156 */         if (!this.circleClicked && snapshot.circleReady() && now - this.lastClickAttempt > this.config.arc_hit_cooldown) {
/*     */           
/* 158 */           this.lastClickAttempt = now;
/* 159 */           if (this.actions.click()) {
/* 160 */             this.circleClicked = true;
/* 161 */             this.actions.log("circulo: clique nativo aceito na janela de acerto");
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case RESULT:
/* 166 */         setState(State.CONFIRM);
/* 167 */         if (snapshot.won() && !this.resultCounted) {
/* 168 */           this.resultCounted = true;
/* 169 */           this.catches++;
/* 170 */           this.actions.log("peixe confirmado pelo servidor! total: " + this.catches);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 175 */         if (!this.resultConfirmed && snapshot.canConfirm() && now - this.phaseStarted > this.config.confirm_delay && now - this.lastClickAttempt > this.config.confirm_click_interval) {
/*     */           
/* 177 */           this.lastClickAttempt = now;
/* 178 */           if (this.actions.click()) {
/* 179 */             this.resultConfirmed = true;
/* 180 */             this.actions.log("confirmacao nativa aceita");
/*     */           } 
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case TRANSITION:
/* 187 */         if (this.state == State.IDLE) setState(State.WAIT);  break;
/*     */       case IDLE:
/* 189 */         throw new IllegalStateException("IDLE tratado antes da sessao");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void observeSession(NativeFishingSnapshot snapshot, double now) {
/* 194 */     if (this.hasSession && this.sessionId == snapshot.sessionId())
/* 195 */       return;  this.hasSession = true;
/* 196 */     this.sessionId = snapshot.sessionId();
/* 197 */     this.nativePhase = null;
/* 198 */     this.sessionStarted = now;
/* 199 */     this.phaseStarted = now;
/* 200 */     this.castStarted = Double.NaN;
/* 201 */     this.minigameSeen = this.circleClicked = this.resultCounted = this.resultConfirmed = this.cancelRequested = false;
/* 202 */     this.acceptedArcSequence = this.acceptedArcHits = this.acceptedAttractSequence = Integer.MIN_VALUE;
/* 203 */     this.arcHits = snapshot.arcHits();
/* 204 */     this.actions.log("sessao de pesca nativa: " + this.sessionId);
/*     */   } public static interface Actions {
/*     */     boolean start(); boolean click(); boolean cancel(); void log(String param1String); }
/*     */   private void idle(double now) {
/* 208 */     if (this.hasSession) {
/* 209 */       this.hasSession = false;
/* 210 */       this.nativePhase = null;
/* 211 */       this.castStarted = Double.NaN;
/* 212 */       this.waitUntil = now + this.config.after_catch_wait;
/* 213 */       setState(State.WAIT);
/*     */     } 
/* 215 */     if (now < this.waitUntil) { setState(State.WAIT); return; }
/* 216 */      if (Double.isNaN(this.castStarted)) this.castStarted = now; 
/* 217 */     if (now - this.castStarted > this.config.cast_timeout) {
/* 218 */       this.waitUntil = now + this.config.after_catch_wait;
/* 219 */       this.castStarted = Double.NaN;
/* 220 */       setState(State.WAIT);
/*     */       return;
/*     */     } 
/* 223 */     setState(State.CAST);
/* 224 */     if (now - this.lastStartAttempt >= this.config.cast_retry_interval) {
/* 225 */       this.lastStartAttempt = now;
/* 226 */       if (this.actions.start()) this.actions.log("arremesso nativo solicitado"); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean resetIfTimedOut(double now, double timeout) {
/* 231 */     if (this.cancelRequested) return true; 
/* 232 */     if (now - this.sessionStarted <= timeout || !this.config.allow_shift_reset || this.minigameSeen || now - this.lastMinigame < this.config.recent_minigame_guard) {
/* 233 */       return false;
/*     */     }
/* 235 */     if (this.actions.cancel()) {
/* 236 */       this.cancelRequested = true;
/* 237 */       setState(State.WAIT);
/* 238 */       this.actions.log("tempo limite: reinicio nativo solicitado");
/* 239 */       return true;
/*     */     } 
/* 241 */     return false;
/*     */   }
/*     */   
/*     */   private void setState(State next) {
/* 245 */     if (this.state != next) this.actions.log("estado nativo: " + String.valueOf(this.state) + " -> " + String.valueOf(next)); 
/* 246 */     this.state = next;
/*     */   }
/*     */   
/*     */   private static void requireTime(double now) {
/* 250 */     if (!Double.isFinite(now)) throw new IllegalArgumentException("Tempo monotonic deve ser finito"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\NativeFishingEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */