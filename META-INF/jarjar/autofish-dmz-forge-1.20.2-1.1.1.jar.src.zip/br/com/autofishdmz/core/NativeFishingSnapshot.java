/*    */ package br.com.autofishdmz.core;public final class NativeFishingSnapshot extends Record { private final long sessionId; private final Phase phase; private final int sequence; private final int arcHits; private final boolean arcReady; private final boolean circleReady; private final boolean won; private final boolean canConfirm;
/*    */   private final boolean bitePending;
/*    */   
/*  4 */   public NativeFishingSnapshot(long sessionId, Phase phase, int sequence, int arcHits, boolean arcReady, boolean circleReady, boolean won, boolean canConfirm, boolean bitePending) { this.sessionId = sessionId; this.phase = phase; this.sequence = sequence; this.arcHits = arcHits; this.arcReady = arcReady; this.circleReady = circleReady; this.won = won; this.canConfirm = canConfirm; this.bitePending = bitePending; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lbr/com/autofishdmz/core/NativeFishingSnapshot;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*  4 */     //   0	7	0	this	Lbr/com/autofishdmz/core/NativeFishingSnapshot; } public long sessionId() { return this.sessionId; } public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lbr/com/autofishdmz/core/NativeFishingSnapshot;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lbr/com/autofishdmz/core/NativeFishingSnapshot; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lbr/com/autofishdmz/core/NativeFishingSnapshot;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #4	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lbr/com/autofishdmz/core/NativeFishingSnapshot;
/*  4 */     //   0	8	1	o	Ljava/lang/Object; } public Phase phase() { return this.phase; } public int sequence() { return this.sequence; } public int arcHits() { return this.arcHits; } public boolean arcReady() { return this.arcReady; } public boolean circleReady() { return this.circleReady; } public boolean won() { return this.won; } public boolean canConfirm() { return this.canConfirm; } public boolean bitePending() { return this.bitePending; }
/*    */ 
/*    */   
/*  7 */   public enum Phase { IDLE, CAST, ATTRACT, ARC, CIRCLE, TRANSITION, RESULT; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NativeFishingSnapshot(long sessionId, Phase phase, int sequence, int arcHits, boolean arcReady, boolean circleReady, boolean won, boolean canConfirm) {
/* 13 */     this(sessionId, phase, sequence, arcHits, arcReady, circleReady, won, canConfirm, false);
/*    */   }
/*    */   
/*    */   public static NativeFishingSnapshot idle() {
/* 17 */     return new NativeFishingSnapshot(-1L, Phase.IDLE, 0, 0, false, false, false, false);
/*    */   } }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\NativeFishingSnapshot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */