/*     */ package br.com.autofishdmz.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FishingDetector
/*     */ {
/*     */   private static final int DIRECTIONS = 16;
/*     */   private static final int INNER_COUNT = 12;
/*     */   private static final int SCAN_START = 60;
/*     */   private static final int SCAN_COUNT = 250;
/*     */   private static final int ANGLE_START = 16;
/*     */   private static final int ANGLE_COUNT = 149;
/*  19 */   private static final Pattern ARC_GAP = Pattern.compile("R([^R]{1,14})R");
/*     */ 
/*     */ 
/*     */   
/*  23 */   private static final int[] SAT_DIV = new int[256]; private final int[][] presence; private final int[][] zones;
/*  24 */   private static final int[] HUE_DIV = new int[256]; private final int[][] inner;
/*     */   static {
/*  26 */     for (int i = 1; i < 256; i++) {
/*  27 */       SAT_DIV[i] = (int)Math.rint(1044480.0D / i);
/*  28 */       HUE_DIV[i] = (int)Math.rint(737280.0D / 6.0D * i);
/*     */     } 
/*     */   }
/*     */   private final int[][] scan; private final int[] centreDot; private final int shiftX0;
/*     */   private final int shiftX1;
/*     */   private final int shiftY0;
/*     */   private final int shiftY1;
/*     */   private final int cropX0;
/*     */   private final int cropX1;
/*     */   private final int cropY0;
/*     */   private final int cropY1;
/*     */   private final double triggerRadius;
/*     */   
/*     */   public FishingDetector(int width, int height, double scale, double circleTriggerRadius) {
/*  42 */     if (width < 1 || height < 1 || width > 65535 || height > 65535 || !Double.isFinite(scale) || scale <= 0.0D || 
/*  43 */       !Double.isFinite(circleTriggerRadius) || circleTriggerRadius <= 0.0D) {
/*  44 */       throw new IllegalArgumentException("Invalid frame dimensions, scale or trigger radius");
/*     */     }
/*  46 */     double cx = width / 2.0D, cy = height / 2.0D;
/*  47 */     this.cropX0 = (int)Math.max(0.0D, cx - 330.0D * scale);
/*  48 */     this.cropX1 = Math.max(this.cropX0 + 1, (int)Math.min(width, cx + 330.0D * scale));
/*  49 */     this.cropY0 = (int)Math.max(0.0D, cy - 330.0D * scale);
/*  50 */     this.cropY1 = Math.max(this.cropY0 + 1, (int)Math.min(height, cy + 460.0D * scale));
/*  51 */     this.triggerRadius = circleTriggerRadius;
/*  52 */     this.presence = arcPoints(cx - 2.0D * scale, cy + 155.0D * scale, scale, new int[] { 194, 212 });
/*  53 */     this.zones = arcPoints(cx - 2.0D * scale, cy + 155.0D * scale, scale, new int[] { 190, 196, 209, 215 });
/*  54 */     this.inner = radialPoints(cx, cy, scale, 50, 12);
/*  55 */     this.scan = radialPoints(cx, cy, scale, 60, 250);
/*  56 */     this
/*  57 */       .centreDot = new int[] { point(cx + 12.0D * scale, cy), point(cx - 12.0D * scale, cy), point(cx, cy + 12.0D * scale), point(cx, cy - 12.0D * scale) };
/*     */     
/*  59 */     double scx = cx + 237.0D * scale, scy = cy + 433.0D * scale;
/*  60 */     this.shiftX0 = Math.max(this.cropX0, (int)Math.max(0.0D, scx - 55.0D * scale));
/*  61 */     this.shiftX1 = Math.min(this.cropX1, (int)Math.min(width, scx + 55.0D * scale));
/*  62 */     this.shiftY0 = Math.max(this.cropY0, (int)Math.max(0.0D, scy - 14.0D * scale));
/*  63 */     this.shiftY1 = Math.min(this.cropY1, (int)Math.min(height, scy + 14.0D * scale));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int point(double x, double y) {
/*  69 */     int px = Math.max(this.cropX0, Math.min(this.cropX1 - 1, (int)Math.rint(x)));
/*  70 */     int py = Math.max(this.cropY0, Math.min(this.cropY1 - 1, (int)Math.rint(y)));
/*  71 */     return py << 16 | px;
/*     */   }
/*     */   
/*     */   private int[][] arcPoints(double cx, double cy, double scale, int[] radii) {
/*  75 */     int[][] points = new int[radii.length][149];
/*  76 */     for (int row = 0; row < radii.length; row++) {
/*  77 */       for (int i = 0; i < 149; i++) {
/*  78 */         double angle = Math.toRadians((16 + i));
/*  79 */         points[row][i] = point(cx + radii[row] * scale * Math.cos(angle), cy - radii[row] * scale * 
/*  80 */             Math.sin(angle));
/*     */       } 
/*     */     } 
/*  83 */     return points;
/*     */   }
/*     */   
/*     */   private int[][] radialPoints(double cx, double cy, double scale, int start, int count) {
/*  87 */     int[][] points = new int[16][count];
/*  88 */     for (int d = 0; d < 16; d++) {
/*  89 */       double angle = Math.toRadians(d * 360.0D / 16.0D);
/*  90 */       for (int i = 0; i < count; i++) {
/*  91 */         double radius = (start + i) * scale;
/*  92 */         points[d][i] = point(cx + radius * Math.cos(angle), cy + radius * Math.sin(angle));
/*     */       } 
/*     */     } 
/*  95 */     return points;
/*     */   }
/*     */   
/*     */   public Detection analyze(PixelSource pixels) {
/*  99 */     Objects.requireNonNull(pixels, "pixels");
/* 100 */     boolean shift = shiftVisible(pixels);
/* 101 */     double fraction = 1.0D;
/* 102 */     for (int[] arrayOfInt : this.presence) {
/* 103 */       int count = 0;
/* 104 */       for (int p : arrayOfInt) {
/* 105 */         char color = classify(hsv(pixels, p));
/* 106 */         if (color == 'o' || color == 'R' || color == 'W') count++; 
/*     */       } 
/* 108 */       fraction = Math.min(fraction, count / 149.0D);
/*     */     } 
/* 110 */     boolean arcBar = (fraction > 0.5D);
/* 111 */     boolean hasRed = false;
/* 112 */     String[] profiles = new String[this.zones.length];
/* 113 */     for (int row = 0; row < this.zones.length; row++) {
/* 114 */       char[] profile = new char[149];
/* 115 */       int reds = 0;
/* 116 */       for (int i = 0; i < 149; i++) {
/* 117 */         profile[i] = classify(hsv(pixels, this.zones[row][i]));
/* 118 */         if (profile[i] == 'R') reds++; 
/*     */       } 
/* 120 */       profiles[row] = new String(profile);
/* 121 */       if (reds >= 6) hasRed = true; 
/*     */     } 
/* 123 */     if (fraction > 0.7D && hasRed) {
/* 124 */       int votes = 0;
/* 125 */       for (String profile : profiles) {
/* 126 */         Matcher gaps = ARC_GAP.matcher(profile);
/* 127 */         while (gaps.find()) {
/* 128 */           if (gaps.group(1).indexOf('W') >= 0) {
/* 129 */             votes++;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 134 */       return new Detection(true, (votes >= 2), false, null, false, shift, arcBar, false, votes, null);
/*     */     } 
/*     */     
/* 137 */     int whiteDirections = 0;
/* 138 */     for (int[] arrayOfInt : this.inner) {
/* 139 */       for (int p : arrayOfInt) {
/* 140 */         int hsv = hsv(pixels, p);
/* 141 */         if (saturation(hsv) < 40 && value(hsv) > 230) {
/* 142 */           whiteDirections++;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 147 */     boolean circleVisible = (whiteDirections >= 8);
/* 148 */     int centreReds = 0;
/* 149 */     for (int p : this.centreDot) {
/* 150 */       if (red(hsv(pixels, p))) centreReds++; 
/*     */     } 
/* 152 */     boolean circle = (whiteDirections >= 12 && centreReds >= 2);
/* 153 */     Double radius = null, hotRadius = null;
/* 154 */     if (circle) {
/* 155 */       int[] radii = new int[16], hotRadii = new int[16];
/* 156 */       int radiusCount = 0, hotCount = 0;
/* 157 */       for (int[] arrayOfInt : this.scan) {
/* 158 */         boolean found = false, foundHot = false;
/* 159 */         for (int i = 0; i < 250; i++) {
/* 160 */           int hsv = hsv(pixels, arrayOfInt[i]);
/* 161 */           int h = hue(hsv), s = saturation(hsv), v = value(hsv);
/* 162 */           if (!found && h >= 16 && h <= 28 && s >= 60 && s <= 140 && v >= 240) {
/* 163 */             radii[radiusCount++] = 60 + i;
/* 164 */             found = true;
/*     */           } 
/* 166 */           if (!foundHot && 60 + i <= 160 && h >= 15 && h <= 28 && s >= 160 && v >= 230) {
/* 167 */             hotRadii[hotCount++] = 60 + i;
/* 168 */             foundHot = true;
/*     */           } 
/* 170 */           if (found && (foundHot || 60 + i >= 160))
/*     */             break; 
/*     */         } 
/* 173 */       }  if (radiusCount >= 5) radius = Double.valueOf(median(radii, radiusCount)); 
/* 174 */       if (hotCount >= 8) hotRadius = Double.valueOf(median(hotRadii, hotCount)); 
/*     */     } 
/* 176 */     return new Detection(false, false, circle, radius, (radius != null && radius.doubleValue() <= this.triggerRadius), shift, arcBar, circleVisible, 0, hotRadius);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean shiftVisible(PixelSource pixels) {
/* 181 */     int width = this.shiftX1 - this.shiftX0, height = this.shiftY1 - this.shiftY0;
/* 182 */     if (width <= 0 || height <= 0) return false; 
/* 183 */     int cream = 0, black = 0;
/* 184 */     for (int y = this.shiftY0; y < this.shiftY1; y++) {
/* 185 */       for (int x = this.shiftX0; x < this.shiftX1; x++) {
/* 186 */         int hsv = rgbToHsv(pixels.rgb(x, y));
/* 187 */         int h = hue(hsv), s = saturation(hsv), v = value(hsv);
/* 188 */         if (s < 75 && s > 20 && v > 205 && h >= 14 && h <= 36) cream++; 
/* 189 */         if (v < 60) black++; 
/*     */       } 
/*     */     } 
/* 192 */     double area = width * height;
/* 193 */     return (cream / area > 0.35D && black / area > 0.08D);
/*     */   }
/*     */   
/*     */   private static double median(int[] values, int count) {
/* 197 */     Arrays.sort(values, 0, count);
/* 198 */     return (count % 2 == 0) ? ((values[count / 2 - 1] + values[count / 2]) / 2.0D) : values[count / 2];
/*     */   }
/*     */   
/*     */   private static int hsv(PixelSource pixels, int point) {
/* 202 */     return rgbToHsv(pixels.rgb(point & 0xFFFF, point >>> 16));
/*     */   }
/*     */   
/*     */   static int rgbToHsv(int rgb) {
/* 206 */     int r = rgb >>> 16 & 0xFF, g = rgb >>> 8 & 0xFF, b = rgb & 0xFF;
/* 207 */     int v = Math.max(r, Math.max(g, b));
/* 208 */     int diff = v - Math.min(r, Math.min(g, b));
/* 209 */     int s = diff * SAT_DIV[v] + 2048 >> 12;
/* 210 */     int h = (v == r) ? (g - b) : ((v == g) ? (b - r + 2 * diff) : (r - g + 4 * diff));
/* 211 */     h = h * HUE_DIV[diff] + 2048 >> 12;
/* 212 */     if (h < 0) h += 180; 
/* 213 */     return h << 16 | s << 8 | v;
/*     */   }
/*     */   
/* 216 */   private static int hue(int hsv) { return hsv >>> 16; }
/* 217 */   private static int saturation(int hsv) { return hsv >>> 8 & 0xFF; } private static int value(int hsv) {
/* 218 */     return hsv & 0xFF;
/*     */   } private static boolean red(int hsv) {
/* 220 */     return ((hue(hsv) <= 8 || hue(hsv) >= 172) && saturation(hsv) > 150 && value(hsv) > 150);
/*     */   }
/*     */   private static char classify(int hsv) {
/* 223 */     int h = hue(hsv), s = saturation(hsv), v = value(hsv);
/* 224 */     if (red(hsv)) return 'R'; 
/* 225 */     if (s < 60 && v > 200) return 'W'; 
/* 226 */     if (h >= 9 && h <= 32 && s > 120 && v > 150) return 'o'; 
/* 227 */     return (v < 60) ? '#' : '.';
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\FishingDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */