/*    */ package br.com.autofishdmz.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum State
/*    */ {
/* 20 */   IDLE, CAST, ATTRACT, BITE_WAIT, ARC, CIRCLE, CONFIRM, WAIT;
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\NativeFishingEngine$State.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */