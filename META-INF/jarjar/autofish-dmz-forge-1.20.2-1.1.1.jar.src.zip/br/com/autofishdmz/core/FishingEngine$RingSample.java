/*    */ package br.com.autofishdmz.core;
/*    */ 
/*    */ 
/*    */ final class RingSample
/*    */   extends Record
/*    */ {
/*    */   private final double time;
/*    */   private final double radius;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lbr/com/autofishdmz/core/FishingEngine$RingSample;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #23	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lbr/com/autofishdmz/core/FishingEngine$RingSample;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lbr/com/autofishdmz/core/FishingEngine$RingSample;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #23	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lbr/com/autofishdmz/core/FishingEngine$RingSample;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lbr/com/autofishdmz/core/FishingEngine$RingSample;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #23	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lbr/com/autofishdmz/core/FishingEngine$RingSample;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   private RingSample(double time, double radius) {
/* 23 */     this.time = time; this.radius = radius; } public double time() { return this.time; } public double radius() { return this.radius; }
/*    */ 
/*    */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\FishingEngine$RingSample.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */