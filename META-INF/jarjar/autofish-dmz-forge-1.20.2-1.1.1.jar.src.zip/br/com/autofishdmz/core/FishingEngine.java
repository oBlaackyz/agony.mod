/*     */ package br.com.autofishdmz.core;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FishingEngine
/*     */ {
/*     */   private BotConfig config;
/*     */   private final Actions actions;
/*     */   
/*     */   private enum State
/*     */   {
/*  22 */     IDLE, CAST, ATTRACT, ARC, CIRCLE, CONFIRM, WAIT; } private static final class RingSample extends Record { private final double time; private final double radius;
/*  23 */     private RingSample(double time, double radius) { this.time = time; this.radius = radius; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lbr/com/autofishdmz/core/FishingEngine$RingSample;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #23	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*  23 */       //   0	7	0	this	Lbr/com/autofishdmz/core/FishingEngine$RingSample; } public double time() { return this.time; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lbr/com/autofishdmz/core/FishingEngine$RingSample;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #23	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lbr/com/autofishdmz/core/FishingEngine$RingSample; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lbr/com/autofishdmz/core/FishingEngine$RingSample;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #23	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lbr/com/autofishdmz/core/FishingEngine$RingSample;
/*  23 */       //   0	8	1	o	Ljava/lang/Object; } public double radius() { return this.radius; }
/*     */      }
/*     */ 
/*     */   
/*  27 */   private final Deque<RingSample> ringHistory = new ArrayDeque<>(8);
/*  28 */   private State state = State.IDLE;
/*     */   private boolean running;
/*     */   private boolean suspended;
/*     */   private boolean minigameActive;
/*     */   private boolean circleClicked;
/*     */   private int catches;
/*     */   private int arcHits;
/*     */   private int confirmationsRemaining;
/*     */   private double stateTime;
/*  37 */   private double lastClick = Double.NEGATIVE_INFINITY;
/*  38 */   private double lastCastClick = Double.NEGATIVE_INFINITY;
/*  39 */   private double lastMinigame = Double.NEGATIVE_INFINITY;
/*  40 */   private double nextConfirmation = Double.POSITIVE_INFINITY;
/*     */   
/*     */   public FishingEngine(BotConfig config, Actions actions) {
/*  43 */     this.config = Objects.<BotConfig>requireNonNull(config, "config");
/*  44 */     this.actions = Objects.<Actions>requireNonNull(actions, "actions");
/*  45 */     config.validate();
/*     */   }
/*     */   
/*  48 */   public boolean running() { return this.running; }
/*  49 */   public String state() { return this.state.name(); }
/*  50 */   public int catches() { return this.catches; }
/*  51 */   public int arcHits() { return this.arcHits; } public boolean suspended() {
/*  52 */     return this.suspended;
/*     */   }
/*     */   
/*     */   public void configure(BotConfig config, double now) {
/*  56 */     ((BotConfig)Objects.<BotConfig>requireNonNull(config, "config")).validate();
/*  57 */     requireTime(now);
/*  58 */     this.config = config;
/*  59 */     suspend(now);
/*     */   }
/*     */   
/*     */   public void toggle(double now) {
/*  63 */     requireTime(now);
/*  64 */     if (this.running) {
/*  65 */       stop(now);
/*     */     } else {
/*  67 */       this.running = true;
/*  68 */       this.suspended = false;
/*  69 */       reset(now);
/*  70 */       this.actions.log("LIGADO");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop(double now) {
/*  75 */     requireTime(now);
/*  76 */     this.running = false;
/*  77 */     this.suspended = false;
/*  78 */     reset(now);
/*  79 */     this.actions.log("PAUSADO");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void suspend(double now) {
/*  89 */     requireTime(now);
/*  90 */     if (!this.suspended) {
/*  91 */       this.suspended = true;
/*  92 */       this.actions.releaseAll();
/*  93 */       this.ringHistory.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void update(Detection detection, double now) {
/*  98 */     Objects.requireNonNull(detection, "detection");
/*  99 */     requireTime(now);
/* 100 */     if (!this.running)
/* 101 */       return;  if (this.suspended) {
/* 102 */       this.suspended = false;
/*     */     }
/*     */ 
/*     */     
/* 106 */     if (detection.arc() || detection.arcBar()) {
/* 107 */       this.lastMinigame = now;
/* 108 */       this.minigameActive = true;
/* 109 */       if (this.state != State.ARC) {
/* 110 */         this.actions.releaseAll();
/* 111 */         setState(State.ARC, now);
/* 112 */         this.arcHits = 0;
/*     */       } 
/* 114 */       if (detection.arc() && detection.arcHit() && now - this.lastClick > this.config.arc_hit_cooldown) {
/* 115 */         this.actions.leftClick();
/* 116 */         this.lastClick = now;
/* 117 */         this.arcHits++;
/* 118 */         this.actions.log("arco: clique #" + this.arcHits);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 123 */     if (detection.circle() || detection.circleVisible()) {
/* 124 */       this.lastMinigame = now;
/* 125 */       this.minigameActive = true;
/* 126 */       if (this.state != State.CIRCLE) {
/* 127 */         this.actions.releaseAll();
/* 128 */         setState(State.CIRCLE, now);
/* 129 */         this.ringHistory.clear();
/* 130 */         this.circleClicked = false;
/*     */       } 
/* 132 */       if (!this.circleClicked && detection.circle()) {
/* 133 */         handleCircle(detection, now);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 138 */     if (this.state == State.ARC || this.state == State.CIRCLE) {
/*     */       
/* 140 */       double goneDelay = (this.state == State.CIRCLE && this.circleClicked) ? this.config.circle_gone_time : this.config.minigame_gone_time;
/* 141 */       if (now - this.lastMinigame > goneDelay) {
/* 142 */         if (this.state == State.CIRCLE && this.circleClicked) {
/*     */           
/* 144 */           this.catches++;
/* 145 */           this.actions.log("peixe pescado! total: " + this.catches);
/* 146 */           setState(State.CONFIRM, now);
/* 147 */           this.confirmationsRemaining = this.config.confirm_clicks;
/* 148 */           this.nextConfirmation = now + this.config.confirm_delay;
/*     */         } else {
/* 150 */           this.actions.log("minigame finalizado sem captura completa, reiniciando...");
/* 151 */           this.minigameActive = false;
/* 152 */           setState(State.WAIT, now);
/*     */         } 
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 158 */     switch (this.state) {
/*     */       case CONFIRM:
/* 160 */         if (now > this.nextConfirmation) {
/* 161 */           if (this.confirmationsRemaining > 0) {
/* 162 */             this.actions.leftClick();
/* 163 */             this.lastClick = now;
/* 164 */             this.confirmationsRemaining--;
/* 165 */             this.nextConfirmation = now + this.config.confirm_click_interval;
/*     */           } else {
/* 167 */             this.actions.log("confirmacao: clique esquerdo");
/* 168 */             setState(State.WAIT, now);
/*     */           } 
/*     */         }
/*     */         return;
/*     */       case WAIT:
/* 173 */         if (now - this.stateTime > this.config.after_catch_wait) {
/* 174 */           setState(State.IDLE, now);
/* 175 */           this.minigameActive = false;
/*     */         } 
/*     */         return;
/*     */       case IDLE:
/* 179 */         this.actions.log("iniciando pesca (clique direito)... aguardando [SHIFT]");
/* 180 */         this.actions.rightClick();
/* 181 */         this.lastCastClick = now;
/* 182 */         setState(State.CAST, now);
/*     */         return;
/*     */       case CAST:
/* 185 */         if (detection.shiftHud()) {
/* 186 */           this.actions.log("pesca confirmada (detectado [SHIFT]) -> atraindo peixe");
/* 187 */           setState(State.ATTRACT, now);
/* 188 */           this.lastClick = now;
/*     */           return;
/*     */         } 
/* 191 */         if (now - this.lastCastClick >= this.config.cast_retry_interval) {
/* 192 */           this.actions.rightClick();
/* 193 */           this.lastCastClick = now;
/*     */         } 
/* 195 */         if (now - this.stateTime > this.config.cast_timeout && !recentMinigame(now)) {
/* 196 */           this.actions.log("tempo limite tentando lancar a vara, resetando...");
/* 197 */           tryShiftReset(now);
/* 198 */           setState(State.WAIT, now);
/*     */         } 
/*     */         return;
/*     */       case ATTRACT:
/* 202 */         if (now - this.stateTime > this.config.attract_timeout) {
/* 203 */           if (!recentMinigame(now)) {
/* 204 */             this.actions.log("nenhum peixe apos tempo limite, relancando");
/* 205 */             tryShiftReset(now);
/* 206 */             setState(State.WAIT, now);
/*     */           } 
/*     */           return;
/*     */         } 
/* 210 */         if (now - this.lastClick > this.config.attract_interval) {
/* 211 */           this.actions.leftClick();
/* 212 */           this.lastClick = now;
/*     */         }  return;
/*     */     } 
/* 215 */     throw new IllegalStateException("Estado inesperado: " + String.valueOf(this.state));
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleCircle(Detection detection, double now) {
/* 220 */     String reason = null;
/* 221 */     Double radius = detection.ringRadius();
/* 222 */     if (detection.ringHot() != null) {
/* 223 */       reason = String.format(Locale.ROOT, "anel ficou laranja (r=%.0f)", new Object[] { detection.ringHot() });
/* 224 */     } else if (radius != null) {
/* 225 */       this.ringHistory.addLast(new RingSample(now, radius.doubleValue()));
/* 226 */       for (; this.ringHistory.size() > 8; this.ringHistory.removeFirst());
/* 227 */       double predicted = radius.doubleValue();
/* 228 */       if (this.ringHistory.size() >= 3) {
/* 229 */         RingSample first = this.ringHistory.getFirst();
/* 230 */         RingSample last = this.ringHistory.getLast();
/* 231 */         if (last.time > first.time) {
/* 232 */           double speed = (last.radius - first.radius) / (last.time - first.time);
/* 233 */           predicted += Math.min(0.0D, speed) * this.config.circle_latency;
/*     */         } 
/*     */       } 
/* 236 */       if (predicted <= this.config.circle_trigger_radius) {
/* 237 */         reason = String.format(Locale.ROOT, "anel r=%.0f (previsto %.0f)", new Object[] { radius, Double.valueOf(predicted) });
/*     */       }
/* 239 */     } else if (!this.ringHistory.isEmpty()) {
/* 240 */       RingSample last = this.ringHistory.getLast();
/* 241 */       if (last.radius <= this.config.circle_lost_click_radius && now - last.time > 0.03D) {
/* 242 */         reason = String.format(Locale.ROOT, "anel sumiu perto do centro (ultimo r=%.0f)", new Object[] { Double.valueOf(last.radius) });
/*     */       }
/*     */     } 
/* 245 */     if (reason != null && now - this.lastClick > this.config.arc_hit_cooldown) {
/* 246 */       this.actions.leftClick();
/* 247 */       this.lastClick = now;
/* 248 */       this.circleClicked = true;
/* 249 */       this.actions.log("circulo: clique - " + reason);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean recentMinigame(double now) {
/* 254 */     return (now - this.lastMinigame < this.config.recent_minigame_guard);
/*     */   }
/*     */   
/*     */   private void tryShiftReset(double now) {
/* 258 */     if (!this.config.allow_shift_reset) {
/* 259 */       this.actions.log("reset por Shift desativado nas configuracoes");
/*     */       return;
/*     */     } 
/* 262 */     if (this.state == State.ARC || this.state == State.CIRCLE || this.minigameActive || recentMinigame(now)) {
/* 263 */       this.actions.log("reset por Shift bloqueado: minigame ativo ou recente");
/*     */       return;
/*     */     } 
/* 266 */     this.actions.tapShift();
/*     */   }
/*     */   
/*     */   private void reset(double now) {
/* 270 */     this.actions.releaseAll();
/* 271 */     this.minigameActive = false;
/* 272 */     this.circleClicked = false;
/* 273 */     this.confirmationsRemaining = 0;
/* 274 */     this.nextConfirmation = Double.POSITIVE_INFINITY;
/* 275 */     this.ringHistory.clear();
/* 276 */     setState(State.IDLE, now);
/*     */   }
/*     */   
/*     */   private void setState(State next, double now) {
/* 280 */     if (this.state != next) this.actions.log("estado: " + String.valueOf(this.state) + " -> " + String.valueOf(next)); 
/* 281 */     this.state = next;
/* 282 */     this.stateTime = now;
/*     */   }
/*     */   
/*     */   private static void requireTime(double now) {
/* 286 */     if (!Double.isFinite(now)) throw new IllegalArgumentException("Tempo monotonic deve ser finito"); 
/*     */   }
/*     */   
/*     */   public static interface Actions {
/*     */     void leftClick();
/*     */     
/*     */     void rightClick();
/*     */     
/*     */     void tapShift();
/*     */     
/*     */     void releaseAll();
/*     */     
/*     */     void log(String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\FishingEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */