/*   */ package br.com.autofishdmz.core;
/*   */ 
/*   */ 
/*   */ 
/*   */ public enum Phase
/*   */ {
/* 7 */   IDLE, CAST, ATTRACT, ARC, CIRCLE, TRANSITION, RESULT;
/*   */ }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\NativeFishingSnapshot$Phase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */