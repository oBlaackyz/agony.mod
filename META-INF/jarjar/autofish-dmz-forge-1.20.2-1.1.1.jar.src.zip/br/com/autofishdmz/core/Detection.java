/*   */ package br.com.autofishdmz.core;public final class Detection extends Record { private final boolean arc; private final boolean arcHit; private final boolean circle; private final Double ringRadius; private final boolean circleHit; private final boolean shiftHud; private final boolean arcBar; private final boolean circleVisible; private final int arcVotes;
/*   */   private final Double ringHot;
/*   */   
/* 4 */   public Detection(boolean arc, boolean arcHit, boolean circle, Double ringRadius, boolean circleHit, boolean shiftHud, boolean arcBar, boolean circleVisible, int arcVotes, Double ringHot) { this.arc = arc; this.arcHit = arcHit; this.circle = circle; this.ringRadius = ringRadius; this.circleHit = circleHit; this.shiftHud = shiftHud; this.arcBar = arcBar; this.circleVisible = circleVisible; this.arcVotes = arcVotes; this.ringHot = ringHot; } public final String toString() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> toString : (Lbr/com/autofishdmz/core/Detection;)Ljava/lang/String;
/*   */     //   6: areturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #4	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/* 4 */     //   0	7	0	this	Lbr/com/autofishdmz/core/Detection; } public boolean arc() { return this.arc; } public final int hashCode() { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: <illegal opcode> hashCode : (Lbr/com/autofishdmz/core/Detection;)I
/*   */     //   6: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #4	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	7	0	this	Lbr/com/autofishdmz/core/Detection; } public final boolean equals(Object o) { // Byte code:
/*   */     //   0: aload_0
/*   */     //   1: aload_1
/*   */     //   2: <illegal opcode> equals : (Lbr/com/autofishdmz/core/Detection;Ljava/lang/Object;)Z
/*   */     //   7: ireturn
/*   */     // Line number table:
/*   */     //   Java source line number -> byte code offset
/*   */     //   #4	-> 0
/*   */     // Local variable table:
/*   */     //   start	length	slot	name	descriptor
/*   */     //   0	8	0	this	Lbr/com/autofishdmz/core/Detection;
/* 4 */     //   0	8	1	o	Ljava/lang/Object; } public boolean arcHit() { return this.arcHit; } public boolean circle() { return this.circle; } public Double ringRadius() { return this.ringRadius; } public boolean circleHit() { return this.circleHit; } public boolean shiftHud() { return this.shiftHud; } public boolean arcBar() { return this.arcBar; } public boolean circleVisible() { return this.circleVisible; } public int arcVotes() { return this.arcVotes; } public Double ringHot() { return this.ringHot; }
/*   */ 
/*   */   
/*   */   public static Detection empty() {
/* 8 */     return new Detection(false, false, false, null, false, false, false, false, 0, null);
/*   */   } }


/* Location:              C:\Users\oblaa\OneDrive\Desktop\steel-client-1.20.2-1.5.23.jar!\META-INF\jarjar\autofish-dmz-forge-1.20.2-1.1.1.jar!\br\com\autofishdmz\core\Detection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */